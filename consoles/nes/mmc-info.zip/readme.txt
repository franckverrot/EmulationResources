
  Reading this, you're probably expecting a little explanation of just
what in the hell this archive contains.

  Well, as the filename implies: NES MMC information.

  I was skimming IBM's Patent Database this lovely morning, and managed
to come across some information about common MMCs. Despite my weeks (if
not months) of scavenger hunting for NES information, I totally forgot
Nintendo of Japan and Nintendo of America most likely patented all of
their products.

  Some other tidbits of information I came across:

    * Nintendo patented flow-charts and code diagrams to games which
      resemble Arkanoid, and Tetris (!!!).
    * Nintendo based their first MMC off of an Atari patent.
    * Nintendo created a "hotel video game system."
    * A few images of the Famicom, and the Famicom Disk System.
    * Patents for multiple revisions of Nintendo's CIC lockout chip.
    * The patent for the never-released Nintendo SNES CD-ROM.
    * Nintendo's front-loading mechanism used in the original NES. I'd
      be ashamed if I was the guy who submit the patent...
    * Nintendo's own FM-oriented sound synthesizer, used for creating
      music on the NES.
    * Documentation on the DMA controller used in the SNES; it's an out-
      rageous 70 pages, and nearly 75% of the document covers just HDMA.
      Nintendo also claims they "engineered" and "created" this DMA
      controller. I think otherwise.
    * Konami patented something relating to texture-mapping on 3D objects.
      I just saw the title, didn't read the full description. I'm surprised
      SGI didn't go ballistic over this.
    * Konami's primary patents are all for hand-held shooters and other
      games (most being alien-oriented ;-) ).
    * Capcom released some kind-of music system which involved body move-
      ment and orientation.

  In case you'd like to see for yourself, or search for other patents,
use the below URL. I searched for the Assignee of "Nintendo". There's
about 196 patents (when I looked):

     http://patent.womplex.ibm.com/advquery.html

  NES MMC links which I bookmarked are:

     http://patent.womplex.ibm.com/details?patent_number=4949298
     http://patent.womplex.ibm.com/details?patent_number=5014982
     http://patent.womplex.ibm.com/details?patent_number=5276831

  This URL possibly contains NES information; I didn't do a thorough
check to see if it did, but it may, due to some of the description I
read:

     http://patent.womplex.ibm.com/details?patent_number=4918434

  Here's the URL for that SNES DMA controller I mentioned above:

     http://patent.womplex.ibm.com/details?patent_number=5291189

---

  I hope these GIFs help out, especially for Kevin, since he's the big
NES hardware hacker (right Kevin? :-) ). If anything, they'll teach us
all something (and if not, they'll atleast show you how crazy patents
sound when written by Japanese, then translated to English).

---

                                                  Y0SHi
                                                  (yoshi@parodius.com)
