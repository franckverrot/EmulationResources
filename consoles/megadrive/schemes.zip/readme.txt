68000mem.gif
68z80mem.gif
ctrlarea.gif
ioarea.gif
vdparea.gif
z80mem.gif

These were found at Damaged Cybernetic

1996 Damaged Cybernetic
