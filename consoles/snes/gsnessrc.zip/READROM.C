#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <malloc.h>
#include <time.h>
#include "strings.h"
#include "general.h"
#include "opcodes.h"

/* 
   PLEASE EXCUSE THIS MESS!! DJGPP CAUSES ERRORS FOR SOME REASON
   WHEN I MAKE LOCAL VARIABLES IN FUNCTION MAIN... SO HAD HAD TO
   MAKE THEM ALL GLOBAL!!
*/

short PCinc[256] = {
  8, 6, 8, 4, 5, 3, 5, 6, 3, 2, 2, 4, 6, 4, 6, 5,
  2, 5, 5, 7, 5, 4, 6, 6, 2, 4, 2, 2, 6, 4, 7, 5,
  6, 6, 8, 4, 3, 3, 5, 6, 4, 2, 2, 5, 4, 4, 6, 5,
  2, 5, 5, 7, 4, 4, 6, 6, 2, 4, 2, 2, 4, 4, 7, 5,
  7, 6, 2, 4, 7, 3, 5, 6, 3, 2, 2, 3, 3, 4, 6, 5,
  2, 5, 5, 7, 7, 4, 6, 6, 2, 4, 3, 2, 4, 4, 7, 5,
  6, 6, 6, 4, 3, 3, 5, 6, 4, 2, 2, 6, 5, 4, 6, 5,
  2, 5, 5, 7, 4, 4, 6, 6, 2, 4, 4, 2, 6, 4, 7, 5,
  2, 6, 3, 4, 3, 3, 3, 6, 2, 2, 2, 3, 4, 4, 4, 5,
  2, 6, 5, 7, 4, 4, 4, 6, 2, 5, 2, 2, 4, 5, 5, 5,
  2, 6, 2, 4, 3, 3, 3, 6, 2, 2, 2, 4, 4, 4, 4, 5,
  2, 5, 5, 7, 4, 4, 4, 6, 2, 4, 2, 2, 4, 4, 4, 5,
  2, 6, 3, 4, 3, 3, 5, 6, 2, 2, 2, 3, 4, 4, 4, 5,
  2, 5, 5, 7, 6, 4, 6, 6, 2, 4, 3, 3, 6, 4, 7, 5,
  2, 6, 3, 4, 3, 3, 5, 6, 2, 2, 2, 3, 4, 4, 6, 5,
  2, 5, 5, 7, 5, 4, 6, 6, 2, 4, 4, 2, 6, 4, 7, 5
};

int index, done=0;
int seconds;

long begin, end;

unsigned char opcode;

/* Registers */
unsigned short A, X, Y, D;
unsigned char DB, PB, P;
unsigned short PC, S;
unsigned char PE;
unsigned long t, cputicks=0, totalticks=0;

/* General Variables */
SNESRomInfoStruct GameInfo;
long int fileheader;
HLtype ROMType;
short LoROMovr, HiROMovr, override;
long ops_done=0;

/* Stuff */
unsigned char *CartROM, *SnesRAM, *SnesVRAM, *SnesSRAM;
unsigned char *VidBuffer[3];
char port4212;
short TrippedNMI;
unsigned short Reset;
bginfo BG1Info, BG2Info, BG3Info, BG4Info, BGTemp;

/*Gets info from the cart file.  All the vital stats, hehe*/
void ReadRom(char *File)
{
  SNESRomInfoStruct GI1, GI2;
  int i;
  long Length;
  unsigned int j,k;
  FILE *file_ptr;

  if ((file_ptr=fopen(File,"rb"))==NULL) {
    puts("Cannot open file for reading...");
    exit(255);
  }
  fseek(file_ptr,0,SEEK_END);
  /*fileheader=512;*/
  if ((fileheader=ftell(file_ptr)&8191)!=512)
    puts ("Headerless image");
   else
    {
     printf("%i-byte header detected\n",fileheader);
    }
  printf("Size: %liK\n",ftell(file_ptr)>>10);
  fseek(file_ptr,0x7FC0+fileheader,SEEK_SET);
  fread(&GI1,36,1,file_ptr);
  fseek(file_ptr,0xFFC0+fileheader,SEEK_SET);
  fread(&GI2,sizeof(SNESRomInfoStruct),1,file_ptr);

  ROMType=LoROM;

  j=GI1.Complement | GI1.Checksum;
  k=GI2.Complement | GI2.Checksum;
  if ((j == 65535u)&&(k!=65535u)) {
     puts("LowROM image!");
     GameInfo=GI1;
     ROMType=LoROM; }
  else if ((j!=65535u) && (k==65535u)) {
     puts("HiROM image!");
     GameInfo=GI2;
     ROMType=HiROM; }
  else if (!override) {
     puts("LowROM image!");
     GameInfo=GI1;
     ROMType=LoROM; 
  }
  if (HiROMovr && override) {
     ROMType=HiROM;
     GameInfo=GI2;
     puts("forced to HiROM!");
     }
     else if (LoROMovr && override)
     {
      ROMType=LoROM;
      GameInfo=GI1;
      puts("forced to LoROM!");
     }

  printf("Game title:");
  fflush(stdout);  /*damned buffered output. DJGPP needs this, or things get out of order*/
  for (i=0;i<21;i++)
   {
    putchar(GameInfo.ROM_Title[i]);
   }
  printf("\nLicense: %i, %s\n", GameInfo.License, Licenses[GameInfo.License]);
  puts("");

  fseek(file_ptr,0,SEEK_END);
  Length=(ftell(file_ptr)-fileheader);
  fseek(file_ptr,fileheader,SEEK_SET);
  cputs("Reading ROM... [");
  for (i=0;i<Length;i+=65536) putch(' ');
  cputs("]");
  gotoxy(17,(int)wherey());
  for (i=0;i<Length;i+=65536)
     {
      if ((Length-i)<65536)
        {
         fread(CartROM+i,Length-i,1,file_ptr);
         cputs("P");
        }
      else
        {
         fread(CartROM+i,1,65536,file_ptr);
         cputs("B");
        }
     }
  puts("");
  fclose(file_ptr);
}

short main(short argc, char *argv[])
{
  PB = 0;
  PE=1;
  P = 0x34;
  D=X=Y=A=0;
  PB=DB=0;
  S=0x0100;
  TrippedNMI = false;
  port4212 = 0;
  t = 0;
  
  if (argc != 2)
  {
    printf("Please provide a FIG, SMC, or SFC file to read.\n");
    exit(1);
  }

  AllocateRAM();
  init_opcodes();
  atexit(FreeBuffers);
  ReadRom(argv[1]);
  for (index=0; index < 0x3F; index++)
  {
    memcpy(CartROM+(index<<16)+0x8000, CartROM+(index<<0x0f), 32768);
  }
  printf("ROM read...\n");
  getch();
  Reset = SNESgetword(0xfffc, 0);
  fflush(stdout);
  if (Reset <= 0x7fff) 
  {
    printf("File header corrupt... setting reset vector to 0x8000\n");
    Reset = 0x8000;
  }
  printf("0x%x\n", Reset);
  PC = Reset;

  while (!done)
  {
    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    opcode = SNESgetbyte(PC, PB);

    Opcode[opcode]();

    cputicks += PCinc[opcode];

    if (kbhit()) done = 1;
  }

  ops_done = cputicks;

  printf("Done...\n");

  exit(0);
}
