/*

 This contains variable and function defintions used by both ASM and C++, defined as C for
easier referencing.... NB I had to do this for vars cos, debugger was playing up!?

*/

#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <sys/movedata.h>
#include <pc.h>
#include <dpmi.h>

#include <sys/segments.h>

#include "..\djgpp\allegro\allegro.h"

unsigned char *MappedSaveRamAddress;
unsigned char *MappedLoRamAddress;
unsigned char *MappedWorkRamAddress;
unsigned long RomReadBuffer[64];
unsigned long RomHiReadBuffer[64];

unsigned char *CopyOfScreen;
unsigned short ScreenX,ScreenY;

unsigned long SNESPatch[10];	// Used to Apply Patches!
unsigned long *SNESPatchPtr=&SNESPatch[0];
unsigned long NumPatches=0;

/*
	movl _NumPatches,%ecx
	movl _SNESPatchPtr,%edx
	cmpl $0,%ecx
	je 0f
1:
	movl (%edx),%esi
	movl %esi,%eax
	andl $0x00FFFFFF,%esi
	shrl $24,%eax
	SET_BYTE
	decl %ecx
	jne 1b
0:

 SNESPatch[0]=0x3F7E0B9D;
 NumPatches=1;

*/

unsigned char Div16Table[16*256];	// Used for faster divides etc.
unsigned char SNES_Palette_Buffer[16*256*4];	// So I can access from cc modules!
unsigned char HICOLOUR_Palette_Buffer[256*4];	// values in here are plotted direct to PC!
unsigned char *SNES_Palette=&SNES_Palette_Buffer[0];
unsigned char *HICOLOUR_Palette=&HICOLOUR_Palette_Buffer[0];

#ifdef DEBUG
volatile unsigned long Timer_Counter_Profile=0;
volatile unsigned long Timer_Counter_FPS=0;
unsigned long Frames=0;
unsigned long Total_CPU,Total_Screen;
#endif

short M7X_DATA,M7Y_DATA,M7A_DATA,M7B_DATA,M7C_DATA,M7D_DATA;

unsigned long INT_BANK,RESET_VECTOR;
unsigned long Map_Address;
unsigned char Map_Byte;

unsigned long DOS_VGA=0xA0000;
unsigned char *SNES_Screen;	/* Temp Buffer for screen */

unsigned short VBE_Selector;	/* Used in VESA part of code (non allegro!) */

BITMAP *Lame_Bastard_Allegro_Bitmap;

unsigned char JOYSTICK_ENABLED=0;
unsigned char SPC_ENABLED=0;
// Mode 0 = 320,200 : Mode 1 = 320,200 SQUASH
// Mode 2 = 320,240 : Mode 3 = 256,256
// Mode 4 = 640,480 : Mode 5 = 640,480 STRETCH
unsigned short PC_SCREEN_MODE=0;

unsigned long BKG;
unsigned long Real_PC;
unsigned long store;

unsigned long BKG1;		// These are the pointers to the BKG's used in asmmmmmmblerrrr
unsigned long BKG1a;
unsigned long BKG1b;
unsigned long BKG1c;
unsigned long BKG2;
unsigned long BKG2a;
unsigned long BKG2b;
unsigned long BKG2c;
unsigned long BKG3;
unsigned long BKG3a;
unsigned long BKG3b;
unsigned long BKG3c;
unsigned long BKG4;
unsigned long BKG4a;
unsigned long BKG4b;
unsigned long BKG4c;

unsigned long LayoutBKG1;		// These are the pointers to the BKG's used in asmmmmmmblerrrr
unsigned long LayoutBKG2;
unsigned long LayoutBKG3;
unsigned long LayoutBKG4;

unsigned long ScreenBack1;	/* 64K aligned doubble buffers */
unsigned long ScreenBack1a;
unsigned long ScreenBack1b;
unsigned long ScreenBack1c;
unsigned long ScreenBack2;	/* copy of screenAddress. */
unsigned long ScreenBack2a;
unsigned long ScreenBack2b;
unsigned long ScreenBack2c;
unsigned long ScreenBack3;
unsigned long ScreenBack3a;
unsigned long ScreenBack3b;
unsigned long ScreenBack3c;
unsigned long ScreenBack4;
unsigned long ScreenBack4a;
unsigned long ScreenBack4b;
unsigned long ScreenBack4c;

unsigned long TileCopy;
unsigned long TileCache2;
unsigned long TileCache4;
unsigned long TileCache8;
unsigned long VRamTop;
unsigned long PlanesUnchanged; /* this is set if any tiles are plotted */
unsigned long RenderType; // 0-Screen cached 1-non-cached

unsigned char SNES_COUNTRY;	// Used to allow PAL,NTSC protection checks to work

/* CPU REGISTERS AND STUFF */

unsigned long SNES_X,SNES_Y;
unsigned short SNES_A,SNES_D,SNES_S,SNES_PC,SNES_F;
unsigned char SNES_PB,SNES_DB;

void InvalidDMAMode()
 {
 char Message[100];

 set_gfx_mode(GFX_TEXT,0,0,0,0);

 itoa(Map_Byte,Message,16);

 printf("\nUnsupported DMA Mode! - 0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!

 exit(-1);
 }

void CopySNESScreen()
 {
 if (PC_SCREEN_MODE<4)		/* NON VBE Screen mode */
  blit(Lame_Bastard_Allegro_Bitmap,screen,0,0,0,0,ScreenX,240);
 else
  _movedatal(_my_ds(),(unsigned int)SNES_Screen,VBE_Selector,0,(640*480*2)/4);
 }

#ifdef DEBUG
void InvalidHWRead()
 {
/* char Message[100];
 unsigned long Temp=Map_Address&0x0000FFFF;

 itoa(Temp,Message,16);

 printf("\nRead From Unsupported HW Address! - 0x%s",Message);

 itoa(Map_Byte,Message,16);

 printf(" with 0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!

 getch();*/
 }

void InvalidSPCHWRead()
 {
 char Message[100];
 unsigned long Temp=Map_Address&0x0000FFFF;

 itoa(Temp,Message,16);

 printf("\nRead From Unsupported SPC HW Address! - 0x%s",Message);

 itoa(Map_Byte,Message,16);

 printf(" with 0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!

 }

void InvalidROMWrite()
 {
/* char Message[100];
 unsigned long Temp=Map_Address&0x0000FFFF;

 itoa(Temp,Message,16);

// printf("\nWrite To ROM Ignored - 0x%s",Message);

 itoa(Map_Byte,Message,16);

// printf(" with 0x%s",Message);

// fflush(stdout);	// Flushes output cos its buffered for some reason!*/
 }

void InvalidSPCROMWrite()
 {
 char Message[100];
 unsigned long Temp=Map_Address&0x0000FFFF;

 itoa(Temp,Message,16);

 printf("\nWrite To SPC ROM Ignored - 0x%s",Message);

 itoa(Map_Byte,Message,16);

 printf(" with 0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!
 }

void InvalidHWWrite()
 {
/* char Message[100];
 unsigned long Temp=Map_Address&0x0000FFFF;

 itoa(Temp,Message,16);

 printf("\nWrite To Unsupported HW Address! - 0x%s",Message);

 itoa(Map_Byte,Message,16);

 printf(" with 0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!*/
 }

void InvalidSPCHWWrite()
 {
 char Message[100];
 unsigned long Temp=Map_Address&0x0000FFFF;

 itoa(Temp,Message,16);

 printf("\nWrite To Unsupported SPC HW Address! - 0x%s",Message);

 itoa(Map_Byte,Message,16);

 printf(" with 0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!
 }
#endif

#ifdef DEBUG
void DisplayStatus();
#endif

void InvalidOpcode()
 {
 char Message[100];

 set_gfx_mode(GFX_TEXT,0,0,0,0);

#ifdef DEBUG
 DisplayStatus();
#endif

 itoa(Map_Byte,Message,16);

 printf("\nOpcode Not Currently Supported SORRY! - 0x%s",Message);

 itoa((Map_Address>>16),Message,16);

 printf("\nAt Address 0x%s",Message);

 itoa((Map_Address&0xFFFF),Message,16);

 printf(":0x%s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!

 exit(-1);
 }

void InvalidSPCOpcode()		// Simple at present... register dump will be done l8r
 {
 char Message[100];

 set_gfx_mode(GFX_TEXT,0,0,0,0);

 itoa(Map_Byte,Message,16);

 printf("\nSPC Opcode Not Currently Supported SORRY! - 0x%s",Message);

 itoa((Map_Address&0xFFFF),Message,16);

 printf("\nAt Address 0x%04s",Message);

 fflush(stdout);	// Flushes output cos its buffered for some reason!

 exit(-1);
 }

#ifdef DEBUG
unsigned char TBG1SC,TBG2SC,TBG3SC,TBG4SC,TBGMODE,TTM,TOBSEL,TOAMADDH;
unsigned char PORT0R,PORT1R,PORT2R,PORT3R,PORT0W,PORT1W,PORT2W,PORT3W;
unsigned short TBG1HScr,TBG1VScr,TBG2HScr,TBG2VScr,TBG3HScr,TBG3VScr,TBG4HScr,TBG4VScr;

void DisplayStatus()
 {
 char Message[100],Message2[100];;

 itoa(SNES_PB,Message,16);
 itoa(SNES_PC,Message2,16);

 printf("\nPC - 0x%02s:0x%04s ",Message,Message2);

 itoa(SNES_DB,Message,16);
 itoa(SNES_D,Message2,16);

 printf("D - 0x%02s:0x%04s ",Message,Message2);

 itoa(0,Message,16);
 itoa(SNES_S,Message2,16);

 printf("S - 0x%02s:0x%04s  V01ENZBDIXMC",Message,Message2);

 itoa(SNES_X,Message,16);
 itoa(SNES_Y,Message2,16);

 printf("\n X - 0x%04s      Y - 0x%04s ",Message,Message2);

 itoa(SNES_A,Message,16);
 itoa(SNES_F,Message2,2);

 printf("     A - 0x%04s       %012s",Message,Message2);

 itoa(Map_Byte,Message,16);

 printf("\nOpcode - 0x%s",Message);

 itoa(TBG1SC,Message,16);
 itoa(TBG2SC,Message2,16);

 printf("\nBG1SC - 0x%02s   BG2SC - 0x%02s",Message,Message2);

 itoa(TBG3SC,Message,16);
 itoa(TBG4SC,Message2,16);

 printf("   BG3SC - 0x%02s   BG4SC - 0x%02s",Message,Message2);

 itoa(TBG1HScr,Message,16);
 itoa(TBG1VScr,Message2,16);

 printf("\nBG1H - 0x%04s   BG1V - 0x%04s",Message,Message2);

 itoa(TBG2HScr,Message,16);
 itoa(TBG2VScr,Message2,16);

 printf("   BG2H - 0x%04s   BG2V - 0x%04s",Message,Message2);

 itoa(TBG3HScr,Message,16);
 itoa(TBG3VScr,Message2,16);

 printf("\nBG3H - 0x%04s   BG3V - 0x%04s",Message,Message2);

 itoa(TBG4HScr,Message,16);
 itoa(TBG4VScr,Message2,16);

 printf("   BG4H - 0x%04s   BG4V - 0x%04s",Message,Message2);

 itoa(TBGMODE,Message,16);
 itoa(TTM,Message2,16);

 printf("\nBGMODE - 0x%02s      TM - 0x%02s",Message,Message2);

 itoa(TOBSEL,Message,16);
 itoa(TOAMADDH,Message2,16);

 printf("\nOBSEL - 0x%02s      OAMADDH - 0x%02s",Message,Message2);

 itoa(PORT0R,Message,16);
 itoa(PORT1R,Message2,16);

 printf("\nSPC READ  0 - 0x%02s  1 - 0x%02s",Message,Message2);

 itoa(PORT2R,Message,16);
 itoa(PORT3R,Message2,16);

 printf("  2 - 0x%02s  3 - 0x%02s",Message,Message2);

 itoa(PORT0W,Message,16);
 itoa(PORT1W,Message2,16);

 printf("\nSPC WRITE  0 - 0x%02s  1 - 0x%02s",Message,Message2);

 itoa(PORT2W,Message,16);
 itoa(PORT3W,Message2,16);

 printf("  2 - 0x%02s  3 - 0x%02s",Message,Message2);

 itoa(Real_PC,Message,16);
 itoa(store,Message2,16);

 printf("\n  RealPC - 0x%04s  val - 0x%02s",Message,Message2);


 fflush(stdout);	// Flushes output cos its buffered for some reason!

// getch();
 }

#endif
