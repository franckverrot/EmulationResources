/****************************************************************************\
 * cpu.c                                                                    *
 * R3000A type stuff.                                                       *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include "general.h"
#include "pex.h"
#include "memory.h"
#include "cpu.h"
#include "profile.h"
#include "kbd.h"
#include "kernel.h"
#include "dynamap.h"

/****************************************************************************\
 * global data                                                              *
\****************************************************************************/
ulong   cpuGPR[ 32 ];   // r3000 general purpose registers.
ulong   cpuPC;          // r3000 PC register (ip).
ulong   cpuHI;          // r3000 HI register.
ulong   cpuLO;          // r3000 LO register.
ulong   cpuBreak;       // r3000 break pointer.
ulong   cpuTrap;        // r3000 trap pointer.
ulong   cpuSysCall;     // r3000 syscall pointer.
ulong   cpuExecs;       // # opcodes executed since cpu reset (inaccurate).
ulong   cpuCycles;      // # cycles cpu has used (inaccurate).
ulong   cpuStarts;      // # times cpu has been started.
ulong   cpuBreakPoint;  // not used currently.
ulong   cpuWatch;       // not used currently.
ulong   cpuNA;          // count of unimplemented opcodes run.
vfv     cpuExec;        // used in conjunction with xlat table to start cpu.
int     (*cpuStart) () = cpuNormalStart; // pointer to a cpuStart routine.
char    cpuVersion[] = "v0.1 (glass)";

/****************************************************************************\
 * int cpuReset( void )
 *
 * desc - resets r3000.
 *
 * in   - nothing.
 *
 * out  - all r3000 registers set to 0, expect PC which is set to 0xbfc00000
 *        also resets cpu performance meters.
\****************************************************************************/
int     cpuReset( void    )
{
    int     j;

    for ( j = 0; j < 31; j++ )
        cpuGPR[ j ] = 0;
    cpuHI = 0;
    cpuLO = 0;
    cpuPC = 0xbfc00000;
    cpuExecs = 0;
    cpuCycles = 0;
    cpuStarts = 0;
    cpuWatch = 0;
    cpuNA = 0;

    pexMesg( stderr, "r3000a reset.\n" );

    return 0;
}

/****************************************************************************\
 * int cpuProfileStart( void )
 *
 * desc - starts r3000 in perfomance profiling mode.  a 'RET' instruction
 *  must be encountered in x86 code for cpu to stop.
 *
 * in   - PC should contain address you want to start execution at.
 *  host must be GenuineIntel.
 *
 * out  - cpu has been started and stopped again.  cpuStarts and cpuCycles
 *  have been updated accordingly.  cpuExecs must be updated by mips-x86
 *  macrocode.
\****************************************************************************/
int     cpuProfileStart(   void    )
{
    do
    {
        cpuExec = (void*) (*memoryXlat( cpuPC ));
        dynamapWork = 0;
        StartTSC();
        cpuExec();
        EndTSC();
    }
    while ( dynamapWork );
    cpuCycles += TSC;
    cpuStarts++;
    return 0;
}

/****************************************************************************\
 * cpuNormalStart()
 *
 * desc - starts r3000 in normal mode.  a 'RET' instruction in x86 code must
 *  be encountered for cpu to stop.
 *
 * in   - PC should contain address you want to start execution at.
 *
 * out  - cpu has been started and stopped again.
\****************************************************************************/
int     cpuNormalStart(   void    )
{
    do
    {
        cpuExec = (void*) (*memoryXlat( cpuPC ));
        dynamapWork = 0;
        cpuExec();
    }
    while ( dynamapWork );
    cpuStarts++;
    return 0;
}

/****************************************************************************\
 * end of cpu.c                                                             *
\****************************************************************************/
