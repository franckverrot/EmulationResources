/****************************************************************************\
 * linkdata.c                                                               *
 * linkdata used by mips-x86 compiler to customize generic x86 macrocode.   *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include "linkdata.h"
#include "mips_lib.h"

void    **linkCode[ 3 ];        // pointer to body code tables.
void    **linkData[ 3 ];        // pointer to body data tables.
void    **linkEpilogCode[ 3 ];  // pointer to epilog code tables.
void    **linkEpilogData[ 3 ];  // pointer to epilog data tables.

/****************************************************************************/
void    *linkOpcodeCode[ 64 ] =
    {   &mipsNOPcode,   &mipsNOPcode,   &mipsJcode,     &mipsJALcode,
        &mipsBEQcode,   &mipsBNEcode,   &mipsBLEZcode,  &mipsBGTZcode,
        &mipsADDIcode,  &mipsADDIUcode, &mipsSLTIcode,  &mipsSLTIUcode,
        &mipsANDIcode,  &mipsORIcode,   &mipsXORIcode,  &mipsLUIcode,
        &mipsCOP0code,  &mipsCOP1code,  &mipsCOP2code,  &mipsCOP3code,
        &mipsBEQLcode,  &mipsBNELcode,  &mipsBLEZLcode, &mipsBGTZLcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsLBcode,    &mipsLHcode,    &mipsLWLcode,   &mipsLWcode,
        &mipsLBUcode,   &mipsLHUcode,   &mipsLWRcode,   &mipsNOPcode,
        &mipsSBcode,    &mipsSHcode,    &mipsSWLcode,   &mipsSWcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsSWRcode,   &mipsNOPcode,
        &mipsLLcode,    &mipsLWC1code,  &mipsLWC2code,  &mipsLWC3code,
        &mipsNOPcode,   &mipsLDC1code,  &mipsLDC2code,  &mipsLDC3code,
        &mipsSCcode,    &mipsSWC1code,  &mipsSWC2code,  &mipsSWC3code,
        &mipsNOPcode,   &mipsSDC1code,  &mipsSDC2code,  &mipsSDC3code  };

void    *linkSpecialCode[ 64 ]  =
    {   &mipsSLLcode,   &mipsNOPcode,   &mipsSRLcode,   &mipsSRAcode,
        &mipsSLLVcode,  &mipsNOPcode,   &mipsSRLVcode,  &mipsSRAVcode,
        &mipsJRcode,    &mipsJALRcode,  &mipsNOPcode,   &mipsNOPcode,
        &mipsSYSCALLcode,&mipsBREAKcode,&mipsNOPcode,   &mipsSYNCcode,
        &mipsMFHIcode,  &mipsMTHIcode,  &mipsMFLOcode,  &mipsMTLOcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsMULTcode,  &mipsMULTUcode, &mipsDIVcode,   &mipsDIVUcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsADDcode,   &mipsADDUcode,  &mipsSUBcode,   &mipsSUBUcode,
        &mipsANDcode,   &mipsORcode,    &mipsXORcode,   &mipsNORcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsSLTcode,   &mipsSLTUcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsTGEcode,   &mipsTGEUcode,  &mipsTLTcode,   &mipsTLTUcode,
        &mipsTEQcode,   &mipsNOPcode,   &mipsTNEcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode   };

void    *linkRegimmCode[ 32 ]   =
    {   &mipsBLTZcode,  &mipsBGEZcode,  &mipsBLTZLcode, &mipsBGEZLcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsTGEIcode,  &mipsTGEIUcode, &mipsTLTIcode,  &mipsTLTIUcode,
        &mipsTEQIcode,  &mipsNOPcode,   &mipsTNEIcode,  &mipsNOPcode,
        &mipsBLTZALcode,&mipsBGEZALcode,&mipsBLTZALLcode,&mipsBGEZALLcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode   };

void    **linkMainStdCode[ 3 ] =
    {   linkOpcodeCode, linkRegimmCode, linkSpecialCode };
/****************************************************************************/
linkMIPS    *linkOpcodeData[ 64 ]   =
    {   &mipsNOPdata,   &mipsNOPdata,   &mipsJdata,     &mipsJALdata,
        &mipsBEQdata,   &mipsBNEdata,   &mipsBLEZdata,  &mipsBGTZdata,
        &mipsADDIdata,  &mipsADDIUdata, &mipsSLTIdata,  &mipsSLTIUdata,
        &mipsANDIdata,  &mipsORIdata,   &mipsXORIdata,  &mipsLUIdata,
        &mipsCOP0data,  &mipsCOP1data,  &mipsCOP2data,  &mipsCOP3data,
        &mipsBEQLdata,  &mipsBNELdata,  &mipsBLEZLdata, &mipsBGTZLdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsLBdata,    &mipsLHdata,    &mipsLWLdata,   &mipsLWdata,
        &mipsLBUdata,   &mipsLHUdata,   &mipsLWRdata,   &mipsNOPdata,
        &mipsSBdata,    &mipsSHdata,    &mipsSWLdata,   &mipsSWdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsSWRdata,   &mipsNOPdata,
        &mipsLLdata,    &mipsLWC1data,  &mipsLWC2data,  &mipsLWC3data,
        &mipsNOPdata,   &mipsLDC1data,  &mipsLDC2data,  &mipsLDC3data,
        &mipsSCdata,    &mipsSWC1data,  &mipsSWC2data,  &mipsSWC3data,
        &mipsNOPdata,   &mipsSDC1data,  &mipsSDC2data,  &mipsSDC3data   };

linkMIPS    *linkSpecialData[ 64 ]  =
    {   &mipsSLLdata,   &mipsNOPdata,   &mipsSRLdata,   &mipsSRAdata,
        &mipsSLLVdata,  &mipsNOPdata,   &mipsSRLVdata,  &mipsSRAVdata,
        &mipsJRdata,    &mipsJALRdata,  &mipsNOPdata,   &mipsNOPdata,
        &mipsSYSCALLdata,&mipsBREAKdata,&mipsNOPdata,   &mipsSYNCdata,
        &mipsMFHIdata,  &mipsMTHIdata,  &mipsMFLOdata,  &mipsMTLOdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsMULTdata,  &mipsMULTUdata, &mipsDIVdata,   &mipsDIVUdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsADDdata,   &mipsADDUdata,  &mipsSUBdata,   &mipsSUBUdata,
        &mipsANDdata,   &mipsORdata,    &mipsXORdata,   &mipsNORdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsSLTdata,   &mipsSLTUdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsTGEdata,   &mipsTGEUdata,  &mipsTLTdata,   &mipsTLTUdata,
        &mipsTEQdata,   &mipsNOPdata,   &mipsTNEdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata    };

linkMIPS    *linkRegimmData[ 32 ]   =
    {   &mipsBLTZdata,  &mipsBGEZdata,  &mipsBLTZLdata, &mipsBGEZLdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsTGEIdata,  &mipsTGEIUdata, &mipsTLTIdata,  &mipsTLTIUdata,
        &mipsTEQIdata,  &mipsNOPdata,   &mipsTNEIdata,  &mipsNOPdata,
        &mipsBLTZALdata,&mipsBGEZALdata,&mipsBLTZALLdata,&mipsBGEZALLdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata    };

linkMIPS    **linkMainStdData[ 3 ] =
    {   linkOpcodeData, linkRegimmData, linkSpecialData };
/****************************************************************************/
void    *linkOpcodeDebugCode[ 64 ] =
    {   &mipsNOPcode,   &mipsNOPcode,   &mipsJcode,     &mipsJALcode,
        &mipsBEQcode,   &mipsBNEcode,   &mipsBLEZcode,  &mipsBGTZcode,
        &mipsADDIcode,  &mipsADDIUcode, &mipsSLTIcode,  &mipsSLTIUcode,
        &mipsANDIcode,  &mipsORIcode,   &mipsXORIcode,  &mipsLUIcode,
        &mipsCOP0code,  &mipsCOP1code,  &mipsCOP2code,  &mipsCOP3code,
        &mipsBEQLcode,  &mipsBNELcode,  &mipsBLEZLcode, &mipsBGTZLcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsLBcode,    &mipsLHcode,    &mipsLWLcode,   &mipsLWcode,
        &mipsLBUcode,   &mipsLHUcode,   &mipsLWRcode,   &mipsNOPcode,
        &mipsSBcode,    &mipsSHcode,    &mipsSWLcode,   &mipsSWcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsSWRcode,   &mipsNOPcode,
        &mipsLLcode,    &mipsLWC1code,  &mipsLWC2code,  &mipsLWC3code,
        &mipsNOPcode,   &mipsLDC1code,  &mipsLDC2code,  &mipsLDC3code,
        &mipsSCcode,    &mipsSWC1code,  &mipsSWC2code,  &mipsSWC3code,
        &mipsNOPcode,   &mipsSDC1code,  &mipsSDC2code,  &mipsSDC3code  };

void    *linkSpecialDebugCode[ 64 ]  =
    {   &mipsSLLcode,   &mipsNOPcode,   &mipsSRLcode,   &mipsSRAcode,
        &mipsSLLVcode,  &mipsNOPcode,   &mipsSRLVcode,  &mipsSRAVcode,
        &mipsJRcode,    &mipsJALRcode,  &mipsNOPcode,   &mipsNOPcode,
        &mipsSYSCALLcode,&mipsBREAKcode,&mipsNOPcode,   &mipsSYNCcode,
        &mipsMFHIcode,  &mipsMTHIcode,  &mipsMFLOcode,  &mipsMTLOcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsMULTcode,  &mipsMULTUcode, &mipsDIVcode,   &mipsDIVUcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsADDcode,   &mipsADDUcode,  &mipsSUBcode,   &mipsSUBUcode,
        &mipsANDcode,   &mipsORcode,    &mipsXORcode,   &mipsNORcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsSLTcode,   &mipsSLTUcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsTGEcode,   &mipsTGEUcode,  &mipsTLTcode,   &mipsTLTUcode,
        &mipsTEQcode,   &mipsNOPcode,   &mipsTNEcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode   };

void    *linkRegimmDebugCode[ 32 ]   =
    {   &mipsBLTZcode,  &mipsBGEZcode,  &mipsBLTZLcode, &mipsBGEZLcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsTGEIcode,  &mipsTGEIUcode, &mipsTLTIcode,  &mipsTLTIUcode,
        &mipsTEQIcode,  &mipsNOPcode,   &mipsTNEIcode,  &mipsNOPcode,
        &mipsBLTZALcode,&mipsBGEZALcode,&mipsBLTZALLcode,&mipsBGEZALLcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,
        &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode,   &mipsNOPcode   };

void    **linkMainDebugCode[ 3 ] =
    {   linkOpcodeDebugCode, linkRegimmDebugCode, linkSpecialDebugCode };
/****************************************************************************/
linkMIPS    *linkOpcodeDebugData[ 64 ]   =
    {   &mipsNOPdata,   &mipsNOPdata,   &mipsJdata,     &mipsJALdata,
        &mipsBEQdata,   &mipsBNEdata,   &mipsBLEZdata,  &mipsBGTZdata,
        &mipsADDIdata,  &mipsADDIUdata, &mipsSLTIdata,  &mipsSLTIUdata,
        &mipsANDIdata,  &mipsORIdata,   &mipsXORIdata,  &mipsLUIdata,
        &mipsCOP0data,  &mipsCOP1data,  &mipsCOP2data,  &mipsCOP3data,
        &mipsBEQLdata,  &mipsBNELdata,  &mipsBLEZLdata, &mipsBGTZLdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsLBdata,    &mipsLHdata,    &mipsLWLdata,   &mipsLWdata,
        &mipsLBUdata,   &mipsLHUdata,   &mipsLWRdata,   &mipsNOPdata,
        &mipsSBdata,    &mipsSHdata,    &mipsSWLdata,   &mipsSWdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsSWRdata,   &mipsNOPdata,
        &mipsLLdata,    &mipsLWC1data,  &mipsLWC2data,  &mipsLWC3data,
        &mipsNOPdata,   &mipsLDC1data,  &mipsLDC2data,  &mipsLDC3data,
        &mipsSCdata,    &mipsSWC1data,  &mipsSWC2data,  &mipsSWC3data,
        &mipsNOPdata,   &mipsSDC1data,  &mipsSDC2data,  &mipsSDC3data   };

linkMIPS    *linkSpecialDebugData[ 64 ]  =
    {   &mipsSLLdata,   &mipsNOPdata,   &mipsSRLdata,   &mipsSRAdata,
        &mipsSLLVdata,  &mipsNOPdata,   &mipsSRLVdata,  &mipsSRAVdata,
        &mipsJRdata,    &mipsJALRdata,  &mipsNOPdata,   &mipsNOPdata,
        &mipsSYSCALLdata,&mipsBREAKdata,&mipsNOPdata,   &mipsSYNCdata,
        &mipsMFHIdata,  &mipsMTHIdata,  &mipsMFLOdata,  &mipsMTLOdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsMULTdata,  &mipsMULTUdata, &mipsDIVdata,   &mipsDIVUdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsADDdata,   &mipsADDUdata,  &mipsSUBdata,   &mipsSUBUdata,
        &mipsANDdata,   &mipsORdata,    &mipsXORdata,   &mipsNORdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsSLTdata,   &mipsSLTUdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsTGEdata,   &mipsTGEUdata,  &mipsTLTdata,   &mipsTLTUdata,
        &mipsTEQdata,   &mipsNOPdata,   &mipsTNEdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata    };

linkMIPS    *linkRegimmDebugData[ 32 ]   =
    {   &mipsBLTZdata,  &mipsBGEZdata,  &mipsBLTZLdata, &mipsBGEZLdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsTGEIdata,  &mipsTGEIUdata, &mipsTLTIdata,  &mipsTLTIUdata,
        &mipsTEQIdata,  &mipsNOPdata,   &mipsTNEIdata,  &mipsNOPdata,
        &mipsBLTZALdata,&mipsBGEZALdata,&mipsBLTZALLdata,&mipsBGEZALLdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,
        &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata,   &mipsNOPdata    };

linkMIPS    **linkMainDebugData[ 3 ] =
    {   linkOpcodeDebugData, linkRegimmDebugData, linkSpecialDebugData };
/****************************************************************************/
void    *linkOpcodeEpilogCode[ 64 ] =
    {   &mipsNOEPIcode, &mipsNOEPIcode, &mipsJMPEPIcode, &mipsJMPEPIcode,
        &mipsJEEPIcode, &mipsJNEEPIcode, &mipsJLEEPIcode, &mipsJGEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsJEEPIcode, &mipsJNEEPIcode, &mipsJLEEPIcode, &mipsJGEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode  };

void    *linkRegimmEpilogCode[ 32 ] =
    {   &mipsJLEEPIcode, &mipsJGEEPIcode, &mipsJLEPIcode, &mipsJGEEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsJLEPIcode, &mipsJGEEPIcode, &mipsJLEPIcode, &mipsJGEEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode  };

void    *linkSpecialEpilogCode[ 64 ] =
    {   &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsJPREPIcode, &mipsJPREPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode,
        &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode, &mipsNOEPIcode  };

void    **linkEpilogStdCode[ 3 ] =
    { linkOpcodeEpilogCode, linkRegimmEpilogCode, linkSpecialEpilogCode };
/****************************************************************************/
linkMIPS    *linkOpcodeEpilogData[ 64 ] =
    {   &mipsNOEPIdata, &mipsNOEPIdata, &mipsJMPEPIdata, &mipsJMPEPIdata,
        &mipsJEEPIdata, &mipsJNEEPIdata, &mipsJLEEPIdata, &mipsJGEEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsJEEPIdata, &mipsJNEEPIdata, &mipsJLEEPIdata, &mipsJGEEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata  };

linkMIPS    *linkRegimmEpilogData[ 32 ] =
    {   &mipsJLEEPIdata, &mipsJGEEPIdata, &mipsJLEEPIdata, &mipsJGEEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsJLEPIdata, &mipsJGEEPIdata, &mipsJLEPIdata, &mipsJGEEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata  };

linkMIPS    *linkSpecialEpilogData[ 64 ] =
    {   &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsJPREPIdata, &mipsJPREPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata,
        &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata, &mipsNOEPIdata  };

linkMIPS    **linkEpilogStdData[ 3 ] =
    { linkOpcodeEpilogData, linkRegimmEpilogData, linkSpecialEpilogData };
/****************************************************************************/
void    *linkOpcodeEpilogDebugCode[ 64 ] =
    {   &mipsCNEPIcode, &mipsCNEPIcode, &mipsJMPDEPIcode, &mipsJMPDEPIcode,
        &mipsJEDEPIcode, &mipsJNEDEPIcode, &mipsJLEDEPIcode, &mipsJGDEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsJEDEPIcode, &mipsJNEDEPIcode, &mipsJLEDEPIcode, &mipsJGDEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode  };

void    *linkRegimmEpilogDebugCode[ 32 ] =
    {   &mipsJLEDEPIcode, &mipsJGEDEPIcode, &mipsJLDEPIcode, &mipsJGEDEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsJLDEPIcode, &mipsJGEDEPIcode, &mipsJLDEPIcode, &mipsJGEDEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode  };

void    *linkSpecialEpilogDebugCode[ 64 ] =
    {   &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsJPRDEPIcode, &mipsJPRDEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode,
        &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode, &mipsCNEPIcode  };

void    **linkEpilogDebugCode[ 3 ] =
    { linkOpcodeEpilogDebugCode,    linkRegimmEpilogDebugCode,
      linkSpecialEpilogDebugCode };
/****************************************************************************/
linkMIPS    *linkOpcodeEpilogDebugData[ 64 ] =
    {   &mipsCNEPIdata, &mipsCNEPIdata, &mipsJMPDEPIdata, &mipsJMPDEPIdata,
        &mipsJEDEPIdata, &mipsJNEDEPIdata, &mipsJLEDEPIdata, &mipsJGEDEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsJEDEPIdata, &mipsJNEDEPIdata, &mipsJLEDEPIdata, &mipsJGEDEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata  };

linkMIPS    *linkRegimmEpilogDebugData[ 32 ] =
    {   &mipsJLEDEPIdata, &mipsJGEDEPIdata, &mipsJLEDEPIdata, &mipsJGEDEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsJLDEPIdata, &mipsJGEDEPIdata, &mipsJLDEPIdata, &mipsJGEDEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata  };

linkMIPS    *linkSpecialEpilogDebugData[ 64 ] =
    {   &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsJPRDEPIdata, &mipsJPRDEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata,
        &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata, &mipsCNEPIdata  };

linkMIPS    **linkEpilogDebugData[ 3 ] =
    { linkOpcodeEpilogDebugData,    linkRegimmEpilogDebugData,
      linkSpecialEpilogDebugData };



/****************************************************************************\
 * end of linkdata.c                                                        *
\****************************************************************************/
