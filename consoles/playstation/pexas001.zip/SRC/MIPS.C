/****************************************************************************/
/* mips.c                                                                   */
/* data about r3000a                                                        */
/****************************************************************************/
/* This source code is part of the pex Sony Playstation emulator project.   */
/* Copyright 1997 Geoffrey Wossum, all rights reserved.                     */
/* This version of the pex source code is NOT FOR DISTRIBUTION.             */
/****************************************************************************/

#include <stdio.h>
#include "general.h"
#include "mips.h"
#include "linkdata.h"
#include "pex.h"

/****************************************************************************/
/* pex class tables.                                                        */
/****************************************************************************/
ulong   mipsOpcodeClass[ 64 ] =
    {   classDelay,     classDelay,     classDelay,     classDelay,
        classDelay,     classDelay,     classDelay,     classDelay,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classLikely,    classLikely,    classLikely,    classLikely,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal };


ulong   mipsSpecialClass[ 64 ] =
    {   classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classDelay,     classDelay,     classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal };

ulong   mipsRegimmClass[ 32 ] =
    {   classDelay,     classDelay,     classDelay,     classDelay,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classDelay,     classDelay,     classDelay,     classDelay,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal,
        classNormal,    classNormal,    classNormal,    classNormal };

char    *mipsGPRname[ 32 ] =
    {   "zero",         "at",           "v0",           "v1",
        "a0",           "a1",           "a2",           "a3",
        "t0",           "t1",           "t2",           "t3",
        "t4",           "t5",           "t6",           "t7",
        "s0",           "s1",           "s2",           "s3",
        "s4",           "s5",           "s6",           "s7",
        "t8",           "t9",           "k0",           "k1",
        "gp",           "sp",           "fp",           "ra"    };

char    *mipsOpcodeName[ 64 ] =
    {   "nop",          "???",          "j",            "jal",
        "beq",          "bne",          "blez",         "bgtz",
        "addi",         "addiu",        "slti",         "sltiu",
        "andi",         "ori",          "xori",         "lui",
        "cop0",         "cop1",         "cop2",         "cop3",
        "beql",         "bnel",         "blezl",        "bgtzl",
        "???",          "???",          "???",          "???",
        "???",          "???",          "???",          "???",
        "lb",           "lh",           "lwl",          "lw",
        "lbu",          "lhu",          "lwr",          "???",
        "sb",           "sh",           "swl",          "sw",
        "???",          "???",          "swr",          "???",
        "ll",           "lwc1",         "lwc2",         "lwc3",
        "???",          "ldc1",         "ldc2",         "ldc3",
        "sc",           "swc1",         "swc2",         "swc3",
        "???",          "sdc1",         "sdc2",         "sdc3"  };

char    *mipsSpecialName[ 64 ] =
    {   "sll",          "???",          "srl",          "sra",
        "sllv",         "???",          "srlv",         "srav",
        "jr",           "jalr",         "???",          "???",
        "syscall",      "break",        "???",          "sync",
        "mfhi",         "mthi",         "mflo",         "mtlo",
        "???",          "???",          "???",          "???",
        "mult",         "multu",        "div",          "divu",
        "???",          "???",          "???",          "???",
        "add",          "addu",         "sub",          "subu",
        "and",          "or",           "xor",          "nor",
        "???",          "???",          "slt",          "sltu",
        "???",          "???",          "???",          "???",
        "tge",          "tgeu",         "tlt",          "tltu",
        "teq",          "???",          "tne",          "???",
        "???",          "???",          "???",          "???",
        "???",          "???",          "???",          "???"   };

char    *mipsRegimmName[ 32 ] =
    {   "bltz",         "bgez",         "bltzl",        "bgezl",
        "???",          "???",          "???",          "???",
        "tgei",         "tgeiu",        "tlti",         "tltiu",
        "teqi",         "???",          "tnei",         "???",
        "bltzal",       "bgezal",       "bltzall",      "bgezall",
        "???",          "???",          "???",          "???",
        "???",          "???",          "???",          "???",
        "???",          "???",          "???",          "???"   };

char    *mipsOpcodeOrder[ 64 ] =
    {   "",             "",             "l",            "l",
        "sto",          "sto",          "so",           "so",
        "tso",          "tso",          "tso",          "tso",
        "tso",          "tso",          "tso",          "to",
        "l",            "l",            "l",            "l",
        "sto",          "sto",          "so",           "so",
        "",             "",             "",             "",
        "",             "",             "",             "",
        "tm",           "tm",           "tm",           "tm",
        "tm",           "tm",           "tm",           "",
        "tm",           "tm",           "tm",           "tm",
        "",             "",             "tm",           "",
        "tm",           "tm",           "tm",           "tm",
        "",             "tm",           "tm",           "tm",
        "tm",           "tm",           "tm",           "tm",
        "",             "tm",           "tm",           "tm"    };

char    *mipsSpecialOrder[ 64 ] =
    {
        "dth",          "",             "dth",          "dth",
        "dts",          "",             "dts",          "dts",
        "s",            "ds",           "",             "",
        "l",            "l",            "",             "",
        "d",            "s",            "d",            "s",
        "",             "",             "",             "",
        "st",           "st",           "st",           "st",
        "",             "",             "",             "",
        "dst",          "dst",          "dst",          "dst",
        "dst",          "dst",          "dst",          "dst",
        "",             "",             "dst",          "dst",
        "",             "",             "",             "",
        "st",           "st",           "st",           "st",
        "st",           "",             "st",           "",
        "",             "",             "",             "",
        "",             "",             "",             ""      };

char    *mipsRegimmOrder[ 32 ] =
    {
        "so",           "so",           "so",           "so",
        "",             "",             "",             "",
        "so",           "so",           "so",           "so",
        "so",           "",             "so",           "",
        "so",           "so",           "so",           "so",
        "",             "",             "",             "",
        "",             "",             "",             "",
        "",             "",             "",             ""      };



/****************************************************************************/
/* mipsDecode()                                                             */
/****************************************************************************/
int     mipsDecode(     ulong       opcode,
                        mipsInstr   *info    )
{
    ulong   temp;

    temp = (opcode >> opShift) & opMask;

    if ( temp == opSPECIAL )
    {
        temp = (opcode >> funcShift) & funcMask;
        temp |= mipsSpecialClass[ temp ] | classSpecial;
    }

    else if ( temp == opREGIMM )
    {
        temp = (opcode >> rtShift) & rtMask;
        temp |= mipsRegimmClass[ temp ] | classRegimm;
    }

    else
        temp |= mipsOpcodeClass[ temp ] | classOpcode;

    info->instr = temp;
    info->rs = (opcode >> rsShift) & rsMask;
    info->rt = (opcode >> rtShift) & rtMask;
    info->rd = (opcode >> rdShift) & rdMask;
    info->lo = (opcode >> loShift) & loMask;
    info->sa = (opcode >> saShift) & saMask;
    info->la = (opcode >> laShift) & laMask;

    if ( ( temp == ( classNormal | classSpecial ) ) && ( info->sa == 0 ) )
        info->instr = classNormal | classOpcode;

    return 0;
}

/****************************************************************************/
/* mipsDisasm()                                                             */
/****************************************************************************/
char    *mipsDisasm(    char        *str,
                        ulong       psxptr,
                        mipsInstr   *info   )
{
    char        *name;
    char        *order;
    ulong       inst;
    int         comma;

    inst = info->instr & classMask;

    if ( ( info->instr & classSpecial ) == classSpecial )
    {
        name = mipsSpecialName[ inst ];
        order = mipsSpecialOrder[ inst ];
    }
    else if ( ( info->instr & classRegimm ) == classRegimm )
    {
        name = mipsRegimmName[ inst ];
        order = mipsRegimmOrder[ inst ];
    }
    else
    {
        name = mipsOpcodeName[ inst ];
        order = mipsOpcodeOrder[ inst ];
    }

    sprintf( str, "%-8s ", name );

    comma = 0;
    while ( *order != '\0' )
    {
        if ( comma )
            sprintf( str + strlen( str ), ", " );

        switch ( *order )
        {
            case 's' :  sprintf( str + strlen( str ), "%4s",
                            mipsGPRname[ info->rs ] );
                        break;
            case 't' :  sprintf( str + strlen( str ), "%4s",
                            mipsGPRname[ info->rt ] );
                        break;
            case 'd' :  sprintf( str + strlen( str ), "%4s",
                            mipsGPRname[ info->rd ] );
                        break;
            case 'o' :  if ( (info->instr & classLikely) ||
                             (info->instr & classDelay) )
                            sprintf( str + strlen( str ), "0x%x",
                                mipsCalcJump( psxptr, info ) );
                        else
                            sprintf( str + strlen( str ), "0x%x",
                                info->lo );
                        break;
            case 'l' :  if ( (info->instr & classLikely) ||
                             (info->instr & classDelay) )
                            sprintf( str + strlen( str ), "0x%x",
                                mipsCalcJump( psxptr, info ) );
                        else
                            sprintf( str + strlen( str ), "0x%x",
                                info->la );
                        break;
            case 'm' :  sprintf( str + strlen( str ), "0x%x(%s)",
                            info->lo, mipsGPRname[ info->rs ] );
                        break;
            case 'h' :  sprintf( str + strlen( str ), "0x%x",
                            info->sa );
                        break;
            default  :  sprintf( str + strlen( str ), "ERROR!" );
        }

        comma = 1;
        order++;
    }

    str[ strlen( str ) ] = '\0';


    return str;
}
 
/****************************************************************************/
/* mipsCalcJump()                                                           */
/****************************************************************************/
ulong   mipsCalcJump(   ulong       pc,
                        mipsInstr   *info    )
{
    ulong   inst;
    ulong   minst;
    
    inst = info->instr;
    minst = inst & classMask;
    pc += 4;


    if ( (inst & classOpcode) == classOpcode )
        if ( (minst == opJ) || (minst == opJAL) )
        {
            pc &= 0xf0000000;
            pc |= ( (info->la) << 2 );
            return pc;
        }

    if ( (inst & classSpecial) == classSpecial )
        if ( ( minst == funcJR) || ( minst == funcJALR ) )
        {
            pc &= 0xf0000000;
            pc |= ( (info->la) << 2 );
            return pc;
        }

    inst = (long) ( (short) (info->lo) );

    pc += (long) ( inst * 4 );
    return pc;
}

/****************************************************************************/
/* end of mips.c                                                            */
/****************************************************************************/
