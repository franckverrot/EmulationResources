/****************************************************************************\
 * kernel_t.c                                                               *
 * more tables!  this time related to the PEX-1000 kernel.                  *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include "general.h"
#include "kernel.h"

vfv     kernelA0addr[ 0xb4 ] =
    {   &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI    };

vfv     kernelB0addr[ 0x60 ] =
    {   &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI    };

vfv     kernelC0addr[ 0x1c ] =
    {   &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI,
        &kernelNI,      &kernelNI,      &kernelNI,      &kernelNI    };
                        
/****************************************************************************\
 * end of kernel_t.c                                                        *
\****************************************************************************/
