/****************************************************************************/
/* spu.c                                                                    */
/* emulation of psx SPU.                                                    */
/****************************************************************************/
/* This source code is part of the pex Sony Playstation emulator project.   */
/* Copyright 1997 Geoffrey Wossum, all rights reserved.                     */
/* This version of the pex source code is NOT FOR DISTRIBUTION.             */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#ifdef __DOS__
  #pragma message ( "including midas.h" );
  #include "midas.h"
#endif
#include "general.h"
#include "pex.h"
#include "spu.h"
#include "midasdll.h"


/****************************************************************************/
/* int spuInit()                                                            */
/****************************************************************************/
int spuInit(    void    )
{
    int     found = 0;

    pexMesg( stderr, "initializing sound system.\n" );
    MIDASstartup();

    if ( pexAutoConfig )
    {
        found = MIDASloadConfig( pexMIDAScfg );
        if ( pexDebug && found )
            fprintf( stderr, "using saved MIDAS configuration.\n" );
    }
    
#ifdef __DOS__
    if ( !found && pexAutoConfig )
    {
        pexMesg( stderr, "autodetecting sound card.\n" );
        found = MIDASdetectSoundCard();
        if ( !found && pexDebug )
            fprintf( stderr, "unable to autodetect sound card.\n" );
    }
#endif

    if ( !pexAutoConfig || !found )
        found = MIDASconfig();

    if ( !found )
        pexError( MIDASerror );

    if ( !MIDASinit() )
        pexError( MIDASerror );

#ifdef __DOS__
    fprintf( stderr, "Using %s\n%s, using port %X, IRQ %i and DMA %i\n",
        midasSD->name, midasSD->cardNames[midasSD->cardType-1],
        midasSD->port, midasSD->IRQ, midasSD->DMA);
#endif
    MIDASsaveConfig( pexMIDAScfg );
    if ( !MIDASopenChannels( 24 ) )
        pexError( MIDASerror );

    return 0;
}

/****************************************************************************/
/* int spuDeinit()                                                          */
/****************************************************************************/
int spuDeinit(  void    )
{
    pexMesg( stderr, "shutting down sound system.\n" );

//    if ( !MIDAScloseChannels() )
//        pexError( MIDASerror );
    if ( !MIDASclose() )
        pexError( "error shutting down MIDAS." );

    return 0;
}


/****************************************************************************/
/* end of spu.c                                                             */
/****************************************************************************/
