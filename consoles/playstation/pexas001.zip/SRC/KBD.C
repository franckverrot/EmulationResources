/****************************************************************************/
/* kbd.c                                                                    */
/* keyboard stuff.                                                          */
/****************************************************************************/
/* This source code is part of the pex Sony Playstation emulator project.   */
/* Copyright 1997 Geoffrey Wossum, all rights reserved.                     */
/* This version of the pex source code is NOT FOR DISTRIBUTION.             */
/****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <i86.h>
#include <dos.h>
#include "general.h"
#include "pex.h"
#include "kbd.h"

uchar   *kbdStatus = (uchar*) 0x417;
uchar   kbdSavedStatus;
ulong volatile kbdHit;
void    ( __interrupt __far *kbdOldHandler ) ( void );

/****************************************************************************/
/* kbdHandler()                                                             */
/****************************************************************************/
void __interrupt __far kbdHandler( void )
{
    kbdHit = 1;
    _chain_intr( kbdOldHandler );
}

/****************************************************************************/
/* kbdInit()                                                                */
/****************************************************************************/
int     kbdInit(    void    )
{
    kbdOldHandler = _dos_getvect( 0x9 );
    _dos_setvect( 0x9, kbdHandler );
    return 0;
}

/****************************************************************************/
/* kbdDeinit()                                                              */
/****************************************************************************/
int     kbdDeinit(  void    )
{
    _dos_setvect( 0x9, kbdOldHandler );
    return 0;
}

/****************************************************************************/
/* kbdFlush()                                                               */
/****************************************************************************/
void    kbdFlush(   void    )
{
    while ( kbhit() )
        getch();
    return;
}

/****************************************************************************/
/* kbdNLon()                                                                */
/****************************************************************************/
void    kbdNLon(    void    )
{
    *kbdStatus = *kbdStatus | 0x20;
    return;
}

/****************************************************************************/
/* kbdNLoff()                                                               */
/****************************************************************************/
void    kbdNLoff(   void    )
{
    *kbdStatus = *kbdStatus & 0xdf;
    return;
}

/****************************************************************************/
/* kbdCLon( void    )                                                       */
/****************************************************************************/
void    kbdCLon(    void    )
{
    *kbdStatus = *kbdStatus | 0x40;
    return;
}

/****************************************************************************/
/* kbdCLoff()                                                               */
/****************************************************************************/
void    kbdCLoff(   void    )
{
    *kbdStatus = *kbdStatus & 0xbf;
    return;
}

/****************************************************************************/
/* kbdSLon()                                                                */
/****************************************************************************/
void    kbdSLon(    void    )
{
    *kbdStatus = *kbdStatus | 0x10;
    return;
}

/****************************************************************************/
/* kbdSLoff()                                                               */
/****************************************************************************/
void    kbdSLoff(   void    )
{
    *kbdStatus = *kbdStatus & 0xef;
    return;
}

/****************************************************************************/
/* kbdSaveStatus()                                                          */
/****************************************************************************/
void    kbdSaveStatus(  void    )
{
    kbdSavedStatus = *kbdStatus;
    return;
}

/****************************************************************************/
/* kbdRestoreStatus()                                                       */
/****************************************************************************/
void    kbdRestoreStatus(   void    )
{
    *kbdStatus = kbdSavedStatus;
    return;
}

/****************************************************************************/
/* kbdGetStr()                                                              */
/****************************************************************************/
char    *kbdGetStr( int     y,
                    int     x,
                    int     maxlen,
                    char    *filter,
                    char    *buffer )
{
    char    ch[ 2 ] = " ";

    strcpy( buffer, "" );
    do
    {
        *ch = getch();
//        pexMesg( stderr, "scan = %d\n", *ch );
        if ( ( *ch == 8 ) && ( strlen( buffer ) > 0 ) )
        {
            buffer[ strlen( buffer ) - 1 ] = '\0';
            x--;
            textPut( y, x, " " );
        }
        else if ( ( strlen( buffer ) < maxlen ) &&
            ( strchr( filter, *ch ) != NULL ) )
        {
            strcat( buffer, ch );
            textPut( y, x, ch );
            x++;
        }
    }
    while ( *ch != 13 );

    return buffer;
}


/****************************************************************************/
/* end of kbd.c                                                             */
/****************************************************************************/

