/****************************************************************************\
 * host.c                                                                   *
 * checks system components of host system.                                 *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <i86.h>        // this is Watcom specific.
#include "general.h"
#include "pex.h"
#include "profile.h"
#include "cpu.h"
#include "host.h"

/****************************************************************************\
 * global data.                                                             *
\****************************************************************************/
uchar   hostType;   // host type ( 3=386 class, 4=486 class, 5=Pentium class)
uchar   hostRing;   // host CPL level.
ulong   hostIntel;  // non-zero for GenuineIntel hosts.
ulong   hostSpeed;  // host speed in MHz (GenuineIntel hosts only).
char    hostVendor[ 13 ];  // cpu vendor id string.

/****************************************************************************\
 * void hostGetVendor( void )
 *
 * desc - gets vendor id from Pentium class chips.
 *
 * in   - host must be Pentium class.
 *
 * out  - host vendor id is in hostVendor has NUL terminated string.
\***************************************************************************/
void hostGetVendor( void );
#pragma aux hostGetVendor = \
    "mov    eax, 0" \
    "db     0fh, 0a2h" \
    "mov    dword ptr [ hostVendor ], ebx" \
    "mov    dword ptr [ hostVendor + 4 ], edx" \
    "mov    dword ptr [ hostVendor + 8 ], ecx" \
    "mov    byte ptr [ hostVendor + 12 ], 0" \
    parm [] \
    modify exact [eax ebx ecx edx]

/****************************************************************************\
 * void hostGetCPU( void )
 *
 * desc - determines host cpu class using a PMODE/W specific function.
 *  if PMODE/W is not going to be used, then we just assume system is a
 *  Pentium class system.
 *
 * in   - nothing.
 *
 * out  - host cpu type is in 'hostType'.
\****************************************************************************/
void hostCPU( void );
#ifdef __PMODEW__
#pragma aux hostGetCPU = \
    "mov    eax, 0eeffh " \
    "int    31h" \
    "mov    [ hostType ], cl " \
    "mov    [ hostRing ], ch " \
    parm [] \
    modify exact [eax ebx ecx edx]
#else
//I can't accurately detect CPU's when running under DPMI with DOS4/GW.
//So I'll assume everything's a Pentium.  I can safely (?) assume this because
//only Glide pex will use DOS4/GW.  I don't know of anyone with a 3Dfx Voodoo
//and anything less than a Pentium.
#pragma aux hostGetCPU = \
    "mov    [ hostType ], 5" \
    parm [] \
    modify exact [eax ebx ecx edx]
#endif
    
/****************************************************************************\
 * int hostCpuCheck( void )
 *
 * desc - checks host cpu class and vendor (Pentium class only).
 *
 * in   - nothing.
 *
 * out  - 'hostType' contains host cpu class.
 *        'hostVendor' contains host vendor string if hostType >= 5.
\****************************************************************************/
int     hostCpuCheck(   void    )
{
    hostGetCPU();

    if ( hostType >= 5 )
    {
        pexMesg( stderr, "Pentium or better detected.\n" );
        hostGetVendor();
        if ( strcmp( hostVendor, "GenuineIntel" ) == 0 )
        {
            hostIntel = 1;
            // my Intel plug ;)  don't you hate these smiley faces =8)
            pexMesg( stderr, "GenuineIntel detected (none better ;)\n" );
        }
        else
        {
            pexMesg( stderr, "%s detected.\n", hostVendor );
            hostIntel = 0;
        }
    }
    else
    {
        pexError( "pex requires a Pentium or better." );
    }

    return 0;
}

/****************************************************************************\
 * int hostProfile( void )
 *
 * desc - determines host speed in MHz for GenuineIntel Pentium class
 *  machines.
 *
 * in   - host must be GenuineIntel Pentium-class machine.
 *
 * out  - 'hostSpeed' contains host speed in MHz for... you know.
\****************************************************************************/
int     hostProfile(    void    )
{
    if ( !hostIntel )
        return 0;

    StartTSC();
    delay( 1000 );
    EndTSC();
    hostSpeed = TSC / 1000000;
    pexMesg( stderr, "host processor speed is %uMhz\n", hostSpeed );
    return 0;
}

/****************************************************************************\
 * end of host.c                                                            *
\****************************************************************************/
