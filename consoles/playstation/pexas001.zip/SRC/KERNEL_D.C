/****************************************************************************\
 * kernel_d.c                                                               *
 * c drivers for the psx86 PEX-1000 kernel.  a work in progress.            *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "general.h"
#include "pex.h"
#include "memory.h"
#include "kernel.h"
#include "kbd.h"
#include "cdrom.h"

/****************************************************************************/
/* global data.                                                             */
/****************************************************************************/
ulong       poolTop = poolBegin;
FDtbl       *FDptr;
IODDtbl     *IODDptr;
int         IODDtop;
int         IODDmax;
FILE        *psxSTDOUT;

/****************************************************************************/
/* kernelInit()                                                             */
/****************************************************************************/
int     kernelInit( void    )
{
    kbdSLon();
    pexMesg( stderr, "psx86 PEX-1000 kernel initializing.\n" );
    kernelInitFD( 16 );
    kernelInitIODD( 4 );
    kernelStartTTY();
    cdromDefine();
    kernelInstallServices();

    fprintf( psxSTDOUT, "pex real-time kernel v1.0 by Maxon (aka Geoffrey Wossum).\n" );
    fprintf( psxSTDOUT, "kernel initialized.\n" );
    pexMesg( stderr, "psx86 PEX-1000 kernel online.\n" );
    kbdSLoff();
    return 0;
}

/****************************************************************************/
/* kernelInitFD()                                                           */
/****************************************************************************/
int     kernelInitFD(   int     num )
{
    ulong   FDaddr;

    FDaddr = kernelPoolAlloc( sizeof(FDtbl) * num );
    FDptr = (FDtbl*) memoryConvert( FDaddr );
    *memoryConvert( FDmemptr ) = FDaddr;
    *memoryConvert( FDmemsize ) = sizeof(FDtbl) * num;

    return 0;
}

/****************************************************************************/
/* kernelInitIODD()                                                         */
/****************************************************************************/
int     kernelInitIODD( int     num )
{
    ulong   IODDaddr;

    IODDaddr = kernelPoolAlloc( sizeof(IODDtbl) * num );
    IODDptr = (IODDtbl*) memoryConvert( IODDaddr );
    *memoryConvert( IODDmemptr ) = IODDaddr;
    *memoryConvert( IODDmemsize ) = sizeof(IODDtbl) * num;
    IODDtop = 0;
    IODDmax = num;

    return 0;
}

/****************************************************************************/
/* kernelAllocIODD()                                                        */
/****************************************************************************/
IODDtbl *kernelAllocIODD(   void    )
{
    IODDtbl     *iodd;

    if ( IODDtop == IODDmax )
        pexError( "unable to meet device driver requests." );

    iodd = (IODDtbl*) (*memoryConvert( IODDmemptr ));
    iodd += IODDtop * sizeof( IODDtbl );
    IODDtop++;

    return iodd;
}

/****************************************************************************/
/* kernelOpenSTDOUT()                                                       */
/****************************************************************************/
int     kernelStartTTY(   void    )
{
    psxSTDOUT = fopen( "stdout", "w" );
    if ( psxSTDOUT == NULL )
        pexError( "Unable to open psx86 TTY device." );

    return 0;
}

/****************************************************************************/
/* kernelPoolAlloc()                                                        */
/****************************************************************************/
ulong   kernelPoolAlloc(   ulong   size    )
{
    ulong   ptr;

    if ( poolTop + size > poolEnd )
        pexError( "unable to meet kernel pool memory requests.\n" );

    ptr = poolTop;
    poolTop += size;
    return ptr;
}

/****************************************************************************/
/* kernelInstallServices()                                                  */
/****************************************************************************/
int     kernelInstallServices(  void    )
{
    *memoryXlat( 0x00a0 ) = (ulong) &kernelA0handler;
    *memoryXlat( 0x00b0 ) = (ulong) &kernelB0handler;
    *memoryXlat( 0x00c0 ) = (ulong) &kernelC0handler;
    return 0;
}

/****************************************************************************\
 * end of kernel_d.c                                                        *
\****************************************************************************/
