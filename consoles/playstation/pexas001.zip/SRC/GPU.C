/****************************************************************************\
 * gpu.c                                                                    *
 * emulation of hardware and interface of psx GPU.                          *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include "general.h"
#include "pex.h"
#include "memory.h"
#include "gpu.h"

/****************************************************************************\
 * void gpuG0Handler( void )
 *
 * desc - handler for the G0 register located at 0x1f801810.
 *  !!! this is massively incomplete.
 *
 * in   - this should never be called directly.  the mips-x86 macrocode
 *  library should call this function.
 *
 * out  - G0 write has been processed.  control is returned to the cpu.
\****************************************************************************/
void    gpuG0Handler(   void    )
{
    pexMesg( stderr, "G0 accessed.\n" );
    return;
}

/****************************************************************************\
 * void gpuG1Handler( void )
 *
 * desc - handler for the G1 register located at 0x1f801814.
 *  !!! this is massively incomplete.
 *
 * in   - this should never be called directly.  the mips-x86 macrocode
 *  library should call this function.
 *
 * out  - G1 write has been processed.  control is returned to the cpu.
\****************************************************************************/
void    gpuG1Handler(   void    )
{
    pexMesg( stderr, "G1 accessed.\n" );
    return;
}

/****************************************************************************\
 * int gpuInit( void )
 *
 * desc - initializes the handlers for GPU hardware register writes.
 *
 * in   - this should be called only after a call to memoryInit().
 *
 * out  - GPU hardware register handlers have been added to the memMap's
 *  register handler list.
 *  always returns 0.
\****************************************************************************/
int     gpuInit(    void    )
{
    memoryRegisterTbl[ 0x1810 / 4 ] = &gpuG0Handler;
    memoryRegisterTbl[ 0x1814 / 4 ] = &gpuG1Handler;

    pexMesg( stderr, "gpu initialized.\n" );
    return 0;
}

/****************************************************************************\
 * end gpu.c                                                                *
\****************************************************************************/
