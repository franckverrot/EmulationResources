/****************************************************************************\
 * memory.c                                                                 *
 * the psx memory emulation                                                 *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "general.h"
#include "pex.h"
#include "memory.h"

/****************************************************************************/
/* global data.                                                             */
/****************************************************************************/
ulong   *memoryBase         = NULL;     // pointer to all psx memory.
ulong   *memoryRAM          = NULL;     // pointer to psx RAM.
ulong   *memoryROM          = NULL;     // pointer to psx ROM.
ulong   *memoryParallel     = NULL;     // pointer to parallel port registers.
ulong   *memoryScratch      = NULL;     // pointer to psx scratch cache.
ulong   *memoryRegister     = NULL;     // pointer to psx hardware registers.
ulong   *memoryXlatTbl      = NULL;     // pointer to all pex xlat memory.
ulong   *memoryXlatRAM      = NULL;     // pointer to pex RAM xlat table.
ulong   *memoryXlatScratch  = NULL;     // pointer to pex scratch xlat table.
ulong   *memoryXlatROM      = NULL;     // pointer to psx ROM xlat table.
i86code *memoryIntel        = NULL;     // head of linked list about i86 mem.
ulong   memoryIntelSize     = 0;        // size of all i86 code blocks.
ulong   *memoryConvertTbl[ 0x1000 ];    // used to convert psx ptrs to pc ptrs.
ulong   *memoryXlatAddrTbl[ 0x1000 ];   // used to convert psx ptrs to pc xlats.
void    *memoryRegisterTbl[ 0x1500 / 4 ];   // pointers to register handlers.
ulong   memoryRegisterNA    = 0;        // times an unimplemented register
                                        // has been accessed.
/****************************************************************************\
 * notes
 ****************************************************************************
 *  0x00000000-0x001fffff - RAM
 *  0x1f000000-0x1f?????? - Mapped memory to the parallel port
 *  0x1f800000-0x1f800fff - Scratch Pad
 *  0x1f801000-0x1f80???? - Hardware registers, and misc.
 *  0x80000000-0x801fffff - Mirror of RAM
 *  0xa0000000-0xa01fffff - Mirror of RAM
 *  0xbfc00000-0xbfc7ffff - ROM, kernel, and shell
\****************************************************************************/


/****************************************************************************\
 * int memoryInit( void )
 *
 * desc - initializes the psx86 memory services.
 *
 * in   - nothing.
 *
 * out  - psx86 memory services are active.
 *  all memory has been allocated, all convience pointers have been set up,
 *  the xlat service has been setup, the fast remap service has been setup,
 *  and the register handler services have been initialized.
 *  if memoryInit() fails, then pex is crashed back to the os.
\****************************************************************************/
int     memoryInit( void    )
{
    /* initialize base memory. */
    memoryBase = (ulong*) malloc( memoryBaseSize );
    if ( memoryBase == NULL )
        pexError( "psx base memory allocation failed!" );

    memoryRAM = memoryBase;
    memoryParallel = memoryRAM + memoryRAMsize / 4;
    memoryScratch = memoryParallel + memoryParallelSize / 4;
    memoryRegister = memoryScratch + memoryScratchSize / 4;
    memoryROM = memoryRegister + memoryRegisterSize / 4;
    
    pexMesg( stderr, "psx RAM located at %08xh\n", memoryRAM );
    pexMesg( stderr, "psx ROM located at %08xh\n", memoryROM );
    pexMesg( stderr, "psx scratch located at %08xh\n", memoryScratch );
    pexMesg( stderr, "psx parallel port mapped at %08xh\n", memoryParallel );
    pexMesg( stderr, "psx hardware registers mapped at %08xh\n", memoryRegister );

    /* initialize xlat area. */
    memoryXlatTbl = (ulong*) malloc( memoryXlatSize );
    if ( memoryXlatTbl == NULL )
        pexError( "pex xlat allocation failed!" );

    memoryXlatRAM = memoryXlatTbl;
    memoryXlatScratch = memoryXlatRAM + memoryRAMsize / 4;
    memoryXlatROM = memoryXlatScratch + memoryScratchSize / 4;

    pexMesg( stderr, "pex RAM xlat located at %08xh\n", memoryXlatRAM );
    pexMesg( stderr, "pex ROM xlat located at %08xh\n", memoryXlatROM );
    pexMesg( stderr, "pex scratch xlat located %08xh\n", memoryXlatScratch );

    memoryInitTbl();

    return 0;
}

/****************************************************************************\
 * int memoryInitTbl(void )
 *
 * desc - initializes tables used by psx86 memory services.
 *
 * in   - nothing.
 *
 * out  - fast remap tables have been filled in and register handler tables
 *  have been initialized.
\****************************************************************************/
int     memoryInitTbl(  void    )
{
    int     j;

    for ( j = 0; j < 0x1000; j++ )
    {
        // set all tables to point to bases.
        // this ensures illegal psx addresses to not create memory violation
        // errors.
        memoryConvertTbl[ j ] = memoryRAM;
        memoryXlatAddrTbl[ j ] = memoryXlatRAM;
    }

    for ( j = 0; j < 0x1500 / 4; j++ )
    {
        // set all register handlers to a null handler.
        memoryRegisterTbl[ j ] = &memoryNoRegister;
    }

    // initialize the specific values in the fast remap tables.
    memoryConvertTbl[ 0x001 ] = memoryRAM + 0x100000 / 4;
    memoryXlatAddrTbl[ 0x001 ] = memoryXlatRAM + 0x100000 / 4;
    memoryConvertTbl[ 0x1f0 ] = memoryParallel;
    memoryConvertTbl[ 0x1f8 ] = memoryScratch;
    memoryXlatAddrTbl[ 0x1f8 ] = memoryXlatScratch;
    memoryConvertTbl[ 0x800 ] = memoryRAM;
    memoryXlatAddrTbl[ 0x800 ] = memoryXlatRAM;
    memoryConvertTbl[ 0x801 ] = memoryRAM + 0x100000 / 4;
    memoryXlatAddrTbl[ 0x801 ] = memoryXlatRAM + 0x100000 / 4;
    memoryConvertTbl[ 0xa00 ] = memoryRAM;
    memoryXlatAddrTbl[ 0xa00 ] = memoryXlatRAM;
    memoryConvertTbl[ 0xa01 ] = memoryRAM + 0x100000 / 4;
    memoryXlatAddrTbl[ 0xa01 ] = memoryXlatRAM + 0x100000 / 4;
    memoryConvertTbl[ 0xbfc ] = memoryROM;
    memoryXlatAddrTbl[ 0xbfc ] = memoryXlatROM;

    pexMesg( stderr, "memory conversion tables initialized.\n" );
    return 0;
}

/****************************************************************************\
 * int memoryDeInit( void )
 *
 * desc - shutdowns psx86 memory services.
 *
 * in   - memoryInit() should have been called before this.
 *
 * out  - all memory used by memory services has been freed.  no psx86
 *  services should be used after a call to memoryDeInit()
\****************************************************************************/
int     memoryDeInit(   void    )
{
    if ( memoryBase != NULL )
        free( memoryBase );

    if ( memoryXlatTbl != NULL )
        free( memoryXlatTbl );

    memoryBase = NULL;
    memoryRAM = NULL;
    memoryParallel = NULL;
    memoryROM = NULL;
    memoryRegister = NULL;
    memoryScratch = NULL;
    memoryXlatTbl = NULL;
    memoryXlatRAM = NULL;
    memoryXlatROM = NULL;
    memoryXlatScratch = NULL;

    memoryFreeAllIntel();

    pexMesg( stderr, "psx memory structures destroyed.\n" );

    return 0;
}

/****************************************************************************\
 * ulong *memoryConvert( ulong psxptr )
 *
 * desc - converts a psx space pointer to a pc space pointer.
 *
 * in   - 'psxptr' is a psx space pointer.
 *
 * out  - returns a pc space pointer to the memory pointed to by 'psxptr'.
\****************************************************************************/
ulong   *memoryConvert( ulong   psxptr  )
{
    uchar   *convptr;   // holds the base of the psx space pointer.

    // use the 12 high bits of 'psxptr' to index the memoryConvertTbl.
    convptr = (uchar*) memoryConvertTbl[ psxptr >> 20 ];

    // get the 24 low bits of psxptr.
    psxptr = psxptr & 0x000fffff;

    // adding the 24 low psxptr bits to the value obtained by looking
    // up the 12 high bits of psxptr in memoryConvertTbl gives us the pc
    // space pointer.
    return (ulong*) ( convptr + psxptr );
}

/****************************************************************************\
 * ulong *memoryXlat( ulong psxptr )
 *
 * desc - gives the pointer to the equivalent x86 code for the opcode at
 *  'psxptr'.
 *
 * in   - 'psxptr' is a psx space.  psxptr should be dword aligned (the 2 low
 *  bits should be 0).  a non-dword aligned address will return nonsense.
 *
 * out  - returns an unsigned long pointer to where the x86 code for 'psxptr'
 *  is located.
 *  example - the x86 code for the first instruction of the rom is located at
 *      *memoryXlat( 0xbfc00000 )
 *  the pointer to that memory location is
 *      memoryXlat( 0xbfc00000 )
\****************************************************************************/
ulong*  memoryXlat( ulong   psxptr  )
{
    uchar   *convptr;       // holds pc base for psx ptr.

    // use the 12 high bits of 'psxptr' to index the memoryXlatAddrTbl.
    convptr = (uchar*) memoryXlatAddrTbl[ psxptr >> 20 ];

    // get the 24 low bits of psxptr.
    psxptr = psxptr & 0x000fffff;

    // adding the 24 low psxptr bits to the value obtained by looking
    // up the 12 high bits of psxptr in memoryXlatAddrTbl gives us the
    // pointer to the x86 code for psxptr.
    return (ulong*) ( convptr + psxptr );
}

/****************************************************************************\
 * uchar memoryPeekb( ulong psxptr )
 *
 * desc - returns a byte out of psx memory.  one of those functions that
 *  seems more useful than it is.  I think the only thing that uses this is
 *  the memory dump in the debugger.
 *
 * in   - 'psxptr' is a psx space pointer.
 *
 * out  - returns the value of the byte pointed to by 'psxptr'
\****************************************************************************/
uchar   memoryPeekb(    ulong   psxptr  )
{
    ulong   *memptr;

    memptr = (ulong*) memoryConvert( psxptr );

    return (uchar) *memptr;
}

/****************************************************************************/
/* memoryAllocIntel()                                                       */
/****************************************************************************/
char    *memoryAllocIntel(  ulong   size,
                            ulong   psxstart,
                            ulong   psxstop )
{
    i86code *p;

    p = (i86code*) malloc( sizeof(i86code) );
    p->i86Ptr = (char*) malloc( size );

    if ( p->i86Ptr == NULL )
        pexError( "Unable to allocate memory for recompiling code!" );

    pexMesg( stderr, "%xh bytes of i86 code area allocated at %08xh\n",
        size, p->i86Ptr );

    memoryIntel->prev = p;
    p->next = memoryIntel;
    p->prev = NULL;
    p->size = size;
    p->start = psxstart;
    p->stop = psxstop;
    memoryIntel = p;
    memoryIntelSize += size;

    return p->i86Ptr;
}

/****************************************************************************/
/* memoryFreeIntel()                                                        */
/****************************************************************************/
void    memoryFreeIntel(    char    *intelptr    )
{
    i86code *p;

    p = memoryIntel;

    while ( ( p != NULL ) && ( p->i86Ptr != intelptr ) )
        p = p->next;

    if ( p == NULL )
        pexError( "Unable to locate recompiled code!" );


    free( (void*) p->i86Ptr );
    if ( p->next != NULL )
        p->next->prev = p->prev;

    if ( p->prev != NULL )
        p->prev->next = p->next;
    else
        memoryIntel = p->next;

    memoryIntelSize -= (p->size);
    free( (void*) p );

    pexMesg( stderr, "Deallocated i86 code area at %08xh\n", intelptr );

    return;
}

/****************************************************************************/
/* memoryIntelResize()                                                      */
/****************************************************************************/
int     memoryIntelResize(  char    *intelptr,
                            ulong   newsize )
{
    char    *newptr;
    i86code *p;

    pexMesg( stderr, "resizing intel code at %08x to %x.\n", intelptr, newsize );

    p = memoryIntel;

    while ( ( p != NULL ) && ( p->i86Ptr != intelptr ) )
        p = p->next;

    if ( p == NULL )
        pexError( "Unable to locate recompiled code!" );

    newptr = (char*) realloc( intelptr, newsize );
    if ( newptr != intelptr )
        pexError( "code space resize unlinked compiled code!" );

    memoryIntelSize -= ( p->size - newsize );
    p->size = newsize;

    return 0;
}

/****************************************************************************/
/* memoryFreeAllIntel()                                                     */
/****************************************************************************/
void    memoryFreeAllIntel( void    )
{
    while ( memoryIntel != NULL )
        memoryFreeIntel( memoryIntel->i86Ptr );

    return;
}

/****************************************************************************/
/* memoryBoundIntel()                                                       */
/****************************************************************************/
int     memoryBoundIntel(   ulong   *psxstart,
                            ulong   *psxstop    )
{
    i86code *p;

    p = memoryIntel;

    while ( p != NULL )
    {
        if ( (*psxstart < p->stop) && (p->stop <= memoryRAMsize ) )
            *psxstart = p->stop + 1;
        if ( (*psxstop > p->start) && (p->start <= memoryRAMsize ) )
            *psxstop = p->start - 1;
        p = p->next;
    }

    return 0;
}

/****************************************************************************\
 * void memoryNoRegister( void )
 *
 * desc - generic hardware register handler.  reports unimplemented register.
 *
 * in   - this function should never be called directly.  the register
 *  handler routines in the mips-x86 library will call this.
 *
 * out  - reports unimplemented register to logfile.
\****************************************************************************/
void    memoryNoRegister(   void    )
{
//    pexMesg( stderr, "unimplemented hardware register write.\n" );
    memoryRegisterNA++;
    return;
}

/****************************************************************************/
/* end of memory.c                                                          */
/****************************************************************************/
