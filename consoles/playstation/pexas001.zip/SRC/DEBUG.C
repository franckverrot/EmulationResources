/****************************************************************************\
 * debug.c                                                                  *
 * pex's debugger.                                                          *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "general.h"
#include "pex.h"
#include "memory.h"
#include "cpu.h"
#include "text.h"
#include "mips.h"
#include "intel.h"
#include "debug.h"
#include "profile.h"
#include "host.h"
#include "kbd.h"
#include "dynamap.h"

/****************************************************************************/
/* global data.                                                             */
/****************************************************************************/
ulong   static  debugMemDump    = 0xbfc00000;   // where to dump memory.
ulong   static  debugDisasmOfs  = 0;            // disasm offset from cpu::PC.
ulong           debugSpeed      = 0;            // speed in MHz of host cpu.
ulong           debugOverhead   = 0;            // min debug overhead cycles.
debugBP         *debugBreakPoints = NULL;       // breakpoint information list.
ulong           debugNumBP      = 0;            // count of all breakpoints.
ulong           debugBreakAddr[ debugMaxBP ];   // holds breakpoint addresses.
ulong           debugBreakLinks = 0;            // # of bp's to be relinked.

/****************************************************************************\
 * int debugShell( void )
 *
 * desc - starts up the debugger and handles the shell for it.
 *
 * in   - pex must be in debug mode.
 *
 * out  - user signalled they wanted to exit pex.  always returns 0.
\****************************************************************************/
int     debugShell( void    )
{
    int     ShellDone   = 0;    // used to signal user exit.
    int     keystroke, j;       // user input keycodes.
    char    buffer[ 20 ];       // used in function control.
    ulong   temp;               // temporary variable used in function control.

    pexMesg( stderr, "pex debug shell started.\n" );

    if ( hostIntel )
    {
        pexMesg( stderr, "host is GenuineIntel.  r3000 profiling enabled.\n" );
        hostProfile();
//        debugOverhead = debugCalcOverhead();
        cpuStart = cpuProfileStart;
    }
    else
    {
        pexMesg( stderr, "host is not GenuineIntel.  r3000 profiling disabled.\n" );
    }

    cpuReset();

    // draw static portions of debugger display.
    text80x50();
    textFlood( 0x17 );
    textWrite( 46, 0, "\xFF\x17" );
    textWrite( 46, 0, "[f12] reset r3000" );
    textWrite( 47, 0, "[c] center > on pc       [g] goto memory dump     [G] goto disasm" );
    textWrite( 48, 0 ,"[f4] execute to >        [f7] single step         [f9] run" );
    textWrite( 49, 0, "[alt-x] exit             [] nav r3000 win       [] nav memory win" );

    // accept commands until user requests to exit.
    while ( !ShellDone )
    {
        debugShowState();
        while ( !kbhit() );
        keystroke = getch();
//        fprintf( stderr, "ext. keystroke = %d\n", keystroke );

        switch ( keystroke )
        {   case 0 :    // "special" keystroke (takes the short bus to school).
            {
                keystroke = getch();
//                fprintf( stderr, "ext. keystroke = %d\n", keystroke );
                switch ( keystroke )
                {
                    case 65 :   // f7
                    {
                        debugSingleStep();
                        break;
                    }
                    case 62 :   // f4
                    {
                        debugExecuteUntil( debugDisasmOfs );
                        break;
                    }
                    case 67 :   // f9
                    {
                        debugRun();
                        break;
                    }
                    case 134 :  // f12
                    {
                        cpuReset();
                        memoryRegisterNA = 0;
                        debugDisasmOfs = 0;
                        break;
                    }
                    case 63 :   // f5
                    {
                        /* this debugger function does not work right because
                         * of a bug in the debugExecuteFor function.
                         * I think that's caused by a bug somewhere outside of
                         * the function, but I don't know where. */
                        textPut( 40, 20, "execute how many opcodes ? " );
                        kbdGetStr( 40, 47, 8, decstr, buffer );
                        temp = strtoul( buffer, NULL, 10 );
                        textPut( 40, 20, "                                     " );
                        debugExecuteFor( temp );
                        break;
                    }
                    case 45 :   // alt-x
                    {
                        ShellDone = 1;
                        break;
                    }
                    case 77 :   // right arrow.
                    {
                        debugMemDump += 16;
                        break;
                    }
                    case 75 :   // left arrow.
                    {
                        debugMemDump -= 16;
                        break;
                    }
                    case 72 :   // up arrow.
                    {
                        debugDisasmOfs -= 4;
                        break;
                    }
                    case 80 :   // down arrow.
                    {
                        debugDisasmOfs += 4;
                        break;
                    }
                }
                break;
            }
            case 27 : ;
            case 'c' :
            {
                debugDisasmOfs = 0;
                break;
            }
            case 'g' :
            {
                textPut( 40, 20, "new memory dump address : 0x" );
                kbdGetStr( 40, 48, 8, hexstr, buffer );
                debugMemDump = strtoul( buffer, NULL, 16 );
                textPut( 40, 20, "                                     " );
                break;
            }
            case 'G' :
            {
                textPut( 40, 20, "new r3000 disasm address : 0x" );
                kbdGetStr( 40, 49, 8, hexstr, buffer );
                debugDisasmOfs = strtoul( buffer, NULL, 16 ) - cpuPC;
                textPut( 40, 20, "                                     " );
                break;
            }
            case 'p' :
            {
                textPut( 40, 20, "new pc address : 0x" );
                kbdGetStr( 40, 39, 8, hexstr, buffer );
                cpuPC = strtoul( buffer, NULL, 16 );
                debugDisasmOfs = 0;
                textPut( 40, 20, "                                     " );
                break;
            }
            case 't' :
            {
//                textDump( "pex.tmd" );
                break;
            }
            break;
        }

    }

    // produce final debug report before exitting.
    debugFinalReport();

    pexMesg( stderr, "pex debug shell stopped.\n" );
    return 0;
}

/****************************************************************************\
 * int debugShowState( void )
 *
 * desc - updates various debugger windows.
 *
 * in   - nothing.  should be called by debugShell.
 *
 * out  - r3000 execution window, r3000 register window, psx memory window,
 *  and pex performance window have been updated.  always returns 0.
\****************************************************************************/
int     debugShowState( void    )
{
    textWrite( 0, 0, "\xFF\x17pex debug shell." );
    debugShowR3000A( cpuPC + debugDisasmOfs );
    debugShowRegisters();
    debugShowMemory( debugMemDump );
    debugShowPerformance();
//    debugShowIntel();
    return 0;
}

/****************************************************************************\
 * int debugShowMemory( ulong memptr )
 *
 * desc - dumps 160 bytes of psx memory into a window, in both hex and ascii.
 *
 * in   - 'memptr' a _PSX SPACE_ to the first byte of memory dump.
 *
 * out  - 160 bytes of psx memory, starting at 'memptr' have been dumped to
 *  a window.  always returns 0.
\****************************************************************************/
int     debugShowMemory(    ulong    memptr    )
{
    char    buffer[ 80 ];   // used to build output.
    int     j, k;           // lcv's.
    uchar   foo;            // temporary variable used in pex's longest line.

    textWrite( 26, 0, "\xFF\x17��psx�memory�dump�����������������������������������������������������������Ŀ" );

    for ( j = 0; j < 10; j++ )
    {
        // I think what follows is the longest statement in pex.
        sprintf( buffer,
                 "�%08x  %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x  %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c �",
                 memptr,
                 memoryPeekb( memptr ),
                 memoryPeekb( memptr + 1 ),
                 memoryPeekb( memptr + 2 ),
                 memoryPeekb( memptr + 3 ),
                 memoryPeekb( memptr + 4 ),
                 memoryPeekb( memptr + 5 ),
                 memoryPeekb( memptr + 6 ),
                 memoryPeekb( memptr + 7 ),
                 memoryPeekb( memptr + 8 ),
                 memoryPeekb( memptr + 9 ),
                 memoryPeekb( memptr + 10 ),
                 memoryPeekb( memptr + 11 ),
                 memoryPeekb( memptr + 12 ),
                 memoryPeekb( memptr + 13 ),
                 memoryPeekb( memptr + 14 ),
                 memoryPeekb( memptr + 15 ),
                 ( ( foo = memoryPeekb( memptr ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 1 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 2 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 3 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 4 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 5 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 6 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 7 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 8 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 9 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 10 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 11 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 12 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 13 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 14 ) ) ? foo : 32 ),
                 ( ( foo = memoryPeekb( memptr + 15 ) ) ? foo : 32 ) );
                 // the conditional is to prevent NUL's from being added to the
                 // buffer.  spaces are put in their place.
        memptr += 16;
        textPut( 27 + j, 0, buffer );
    }
    textWrite( 37, 0,         "������������������������������������������������������������������������������" );

    return 0;
}


/****************************************************************************\
 * int debugShowR3000A( ulong memptr )
 *
 * desc - provides a dump of 20 r3000 opcodes, centered on memptr.
 *
 * in   - 'memptr' is a PSX pointer to the mips opcode to center on.
 *
 * out  - an r3000 dump has been produced in a window.
 *  always returns 0.
\****************************************************************************/
int     debugShowR3000A(    ulong   memptr    )
{
    char        buffer[ 160 ];  // holds output.
    int         j, k;           // lcv's.
    ulong*      instr;          // pointer to mips opcode.
    mipsInstr   info;           // holds decoded mips opcode.
    char static *padding =    "                                                ";
        // padding is used to make sure it all looks real nice.

    memptr -= 40;

    textWrite( 2, 0, "\xFF\x17��R3000A�execution���������������������������Ŀ" );

    for ( j = -10; j <= 10; j++ )
    {
        sprintf( buffer, "\xFF\x17�" );

        if ( j == 0 )   // where at the middle line.
            sprintf( buffer + strlen( buffer ), ">" );
        else            // not the middle line.
            sprintf( buffer + strlen( buffer ), " " );

        if ( memptr == cpuPC )  // where at PC. highlight it in red.
            sprintf( buffer + strlen( buffer ), "\xFF\x47%08x ", memptr );
        else                    // not at PC.  don't highlight it.
            sprintf( buffer + strlen( buffer ), "%08x ", memptr );

        instr = memoryConvert( memptr );
        mipsDecode( *instr, &info );
        mipsDisasm( buffer + strlen( buffer ), memptr, &info );
        strcat( buffer, padding + strlen( buffer ) );
        textWrite( 13 + j, 0, buffer );
        textWrite( 13 + j, 45, "\xFF\x17 �" );
        memptr += 4;
    }

    textWrite( 24, 0,        "\xFF\x17�����������������������������������������������" );

    return 0;
}

/****************************************************************************\
 * int debugShowRegisters( void )
 *
 * desc - dumps values of all r3000 registers.
 *
 * in   - nothing.
 *
 * out  - all r3000 general purpose registers, PC, HI, and LO have been
 *  dumped to a window.  always returns 0.
\****************************************************************************/
int     debugShowRegisters( void    )
{
    char    buffer[ 80 ];   // used to build output.
    int     j;              // lcv.

    textWrite( 2, 47, "\xFF\x17��R3000A�registers�������������Ŀ" );

    for ( j = 0; j < 16; j++ )
    {
        sprintf( buffer, "�%4s  %08xh %4s  %08xh�", mipsGPRname[ 2 * j ],
        cpuGPR[ 2 * j ], mipsGPRname[ 2 * j + 1 ], cpuGPR[ 2 * j + 1 ] );
        textWrite( 3 + j, 47, buffer );
    }

    sprintf( buffer, "�  lo  %08xh   hi  %08xh�", cpuLO, cpuHI );
    textWrite( 19, 47, buffer );
    sprintf( buffer, "�  pc  %08xh                �", cpuPC );
    textWrite( 20, 47, buffer );
    textWrite( 21, 47,        "���������������������������������" );
    return 0;
}

/****************************************************************************\
 * int debugShowPerformance( void )
 *
 * desc - provides basic pex perfomance information in a window.
 *
 * in   - nothing.
 *
 * out  - performance information written out to a window.
 *  always returns 0.
\****************************************************************************/
int     debugShowPerformance(   void    )
{
    char    buffer[ 80 ];   // used to build output.
    ulong   avg;            // holds average clock cycles per instruction.
    float   speed;          // holds estimated r3000 speed in MHz.

    // r3000 profiling is only available on GenuineIntel machines.
    if ( hostIntel )
    {
        avg = cpuExecs ? (cpuCycles / cpuExecs - debugOverhead) : 0;
        speed = cpuExecs ? (float) hostSpeed / avg : 0;
    }

    textWrite( 22, 47,        "��pex performance��������������Ŀ" );

    // r3000 profiling is only available on GenuineIntel machines.
    if ( hostIntel )
        sprintf( buffer,          "� r3000 : %3d c/i iMem : %5uk �",
            avg, memoryIntelSize / 1024 );
    else
        sprintf( buffer,          "� r3000 : n/a     iMem : %5uk �",
            memoryIntelSize / 1024 );
    textWrite( 23, 47, buffer );

    // r3000 profiling is only available on GenuineIntel machines.
    if ( hostIntel )
    {
        // next if..else combo ensures it all looks nice.
        if ( speed > 10 )
            sprintf( buffer,          "� r3000 : %3.1fMhz  gte : n/a    �",
                speed );
        else
            sprintf( buffer,          "� r3000 : %3.1fMhz   gte : n/a    �",
                speed );
    }
    else
    {
        sprintf( buffer,          "� r3000 : n/a     gte  : n/a    �" );
    }

    textWrite( 24, 47, buffer );
    textWrite( 25, 47,        "���������������������������������" );
    return 0;
}

/****************************************************************************\
 * int debugInstallBP( ulong psxptr )
 *
 * desc - installs a "breakpoint" into the x86 stream by inserting a RET into
 *  it.  this will cause x86 to return back to the r3kshell.  when this
 *  instruction is hit.  if a breakpoint is installed at an address, it must
 *  be removed before the instruction can be executed, otherwise the
 *  instruction will not run.
 *
 * in   - 'psxptr' is the psx space address of where to install the BP.
 *
 * out  - a breakpoint has been installed at 'psxptr'.
 *  returns 0 if successful, non-zero if unsuccessful.
\****************************************************************************/
int     debugInstallBP( ulong   psxptr  )
{
    debugBP     *bp;
    uchar       *intelptr;

    if ( debugNumBP >= debugMaxBP )
        return 1;   // too many breakpoints installed already.

    bp = (debugBP*) malloc( sizeof( debugBP ) );
    debugNumBP++;

    // add breakpoint into breakpoint list.
    bp->next = debugBreakPoints;
    bp->prev = NULL;
    if ( debugBreakPoints != NULL )
        debugBreakPoints->prev = bp;
    debugBreakPoints = bp;

    bp->psxptr = psxptr;

    // get pc space address of psxptr.
    intelptr = (uchar*) *memoryXlat( psxptr );
//    pexMesg( stderr, "installing breakpoint at %08x (%08x).\n", psxptr,
//        *memoryXlat( psxptr ) );

    // check to see if code has been recompiled yet.
    if ( intelptr == &dynamapProcess )
    {
        // it hasn't, make note, don't install breakcode.
        bp->installed = 0;
        return 0;
    }
    else
    {
        bp->installed = 1;
    }

    // save memory we're installing breakcode to.
    memcpy( bp->opsave, intelptr, sizeof( bp->opsave ) );

    // install breakcode.
    memcpy( intelptr, &debugBreakCode, debugBreakCodeLN );

    // copy PC (psxptr) into breakcode.
    memcpy( intelptr + debugBreakCodePC, &psxptr, sizeof( psxptr ) );

    return 0;
}

/****************************************************************************\
 * int debugRemoveConcreteBP( debugBP *bp)
 *
 * desc - removes the 'bp' referred to in '*bp'.
 *
 * in   - 'bp' is a ptr to the debugBP struct of the breakpoint to be removed.
 *
 * out  - bp has been uninstalled.
 *  returns 0 if successful, non-zero if unsuccessful.
\*****************************************************************************/
int     debugRemoveConcreteBP(  debugBP *bp )
{
    uchar   *intelptr;

    debugNumBP--;

    // get pc space pointer of breakpoint.
    intelptr = (uchar*) *memoryXlat( bp->psxptr );

    // check to see if breakcode is installed.
    if ( bp->installed )
        // remove breakcode from x86 stream.
        memcpy( intelptr, bp->opsave, sizeof( bp->opsave ) );

    // remove bp from debugBreakPoints linked list.
    if ( bp->next != NULL )
        bp->next->prev = bp->prev;

    if ( bp->prev != NULL )
        bp->prev->next = bp->next;

    if ( debugBreakPoints == bp )
        debugBreakPoints = bp->next;

    free( (void*) bp );

    return 0;
}

/*****************************************************************************\
 * int debugRemoveBP( ulong psxptr )
 *
 * desc - this removes a breakpoint at 'psxptr' (if one was installed).
 *
 * in   - 'psxptr' is a psx space pointer of where the breakpoint is to be
 *  removed.
 *
 * out  - breakpoint at 'psxptr' has been removed.
 *  returns 0 if successful, non-zero if unsuccessful.
\*****************************************************************************/
int     debugRemoveBP(  ulong   psxptr  )
{
    debugBP     *bp;    // traverses debugBreakPoints linked list.

    bp = debugBreakPoints;

    while ( ( bp != NULL ) && ( bp->psxptr != psxptr ) )
        bp = bp->next;

    if ( bp == NULL )
        return 1;   // breakpoint was not installed for psxptr.

    debugRemoveConcreteBP( bp );

    return 0;
}

/*****************************************************************************\
 * int debugRemoveAllBP( void )
 *
 * desc - removes all installed debug breakpoints.
 *
 * in   - nothing.
 *
 * out  - all debug breakpoints in debugBreakPoints have been removed.
\*****************************************************************************/
int     debugRemoveAllBP(   void    )
{
    while ( debugBreakPoints != NULL )
        debugRemoveConcreteBP( debugBreakPoints );

    return 0;
}

/****************************************************************************\
 * int debugUnlinkBP()
 *
 * desc - removes all breakpoints, but remembers where they were located.
 *
 * in   - psx86 engine must be ready for work.
 *
 * out  - all breakpoints and breakcode have been removed.  psx space pointers
 *  of all breakpoints have been stored for future use.
\****************************************************************************/
int     debugUnlinkBP(  void    )
{
    debugBreakLinks = 0;

    while ( debugBreakPoints != NULL )
    {
        debugBreakAddr[ debugBreakLinks ] = debugBreakPoints->psxptr;
        debugBreakLinks++;
        debugRemoveConcreteBP( debugBreakPoints );
    }

    return 0;
}

/****************************************************************************\
 * int debugRelinkBP( void )
 *
 * desc - relinks breakpoints and breakcodes broken by debugUnlinkBP().
 *
 * in   - must be proceeded by a call to debugUnlinkBP().
 *
 * out  - all breakpoints broken by debugUnlinkBP() have been relinked.
\****************************************************************************/
int     debugRelinkBP(  void    )
{
    int     j;

    for ( j = 0; j < debugBreakLinks; j++ )
    {
        debugInstallBP( debugBreakAddr[ j ] );
    }

    debugBreakLinks = 0;

    return 0;
}

/****************************************************************************\
 * int debugSingleStep( void )
 *
 * desc - executes the single mips opcode at cpuPC.
 *
 * in   - mips code must have been compiled in debug mode.
 *
 * out  - the single opcode will have been run.
 *  always returns 0.
\****************************************************************************/
int     debugSingleStep(    void    )
{
    /* something wacky about an old mips-x86 compiler required writing
     * something to a file before running recompiled code or pex would crash.
     * I'm not sure why.  I'm not sure if the new one has the same bug.
     * haven't tried it yet.  It must have had something to do with the x86
    \* code cache. */
/*
    pexMesg( stderr, "" );
    cpuStart();
    debugDisasmOfs = 0; //center r3000 disasm on PC.
    return 0;
*/
    mipsInstr   mipsinfo;

    mipsDecode( *memoryConvert( cpuPC ), &mipsinfo );
    debugInstallBP( cpuPC + 4 );

    if ( ( mipsinfo.instr & classDelay ) ||
         ( mipsinfo.instr & classLikely ) )
        debugInstallBP( mipsCalcJump( cpuPC, &mipsinfo ) );

    cpuStart();
    debugDisasmOfs = 0;
    debugRemoveAllBP();

    return 0;

}

/****************************************************************************\
 * int debugRun( void )
 *
 * desc - runs the r3000 until it is interupted by a keystroke.
 *
 * in   - nothing.
 *
 * out  - cpu has run some instructions and then was stopped by a keypress.
 *  always returns 0.
\****************************************************************************/
int     debugRun(   void    )
{
    kbdNLon();          // turn numlock on.
    while ( !kbdHit )   // run r3000 until the kbd is hit.
    {
        cpuStart();
    }
    kbdNLoff();         // turn numlock off.
    getch();            // clear keystroke out of buffer.
    debugDisasmOfs = 0; // center r3000 disasm on PC.
    return 0;
}

/****************************************************************************\
 * int debugExecuteUntil( long absolute )
 *
 * desc - runs instructions until a specified PC is encountered.
 *
 * in   - 'absolute' determines which PC the function will stop on.
 *  this function will stop when it reaches ( PC + absolute ), where PC is the
 *  value of PC when this function is first called.
 *  this seems strange, but it allows me to directly pass debugDisasmOfs into
 *  this function.  ok, I guess it is strange.
 *
 * out  - the r3000 was run until ( PC + absolute ) was reached.  the PC at
 *  the end of debugExecuteUntil will therefore be ( PC + absolute ).
 *  !!! note that if ( PC + absolute ) is never reached, this function will
 *      never exit!
\****************************************************************************/
int     debugExecuteUntil(  long   absolute    )
{
    ulong   target;     // target PC to stop r3000 at when reached.

    // this output was a way to keep an older mips-x86 compiler from crashing.
    // I'm not sure if it's still necesary.  I haven't investigated it yet.
//    pexMesg( stderr, "" );
    target = cpuPC + absolute;  // calculate target PC.
    debugInstallBP( target );   // new.
    kbdNLon();                  // turn the numlock on.
    while ( cpuPC != target )   // keep going until target PC reached.
        cpuStart();

    cpuStart();
    kbdNLoff();                 // turn numlock off.
    debugRemoveBP( target );
    debugDisasmOfs = 0;         // center r3000 disasm on PC.

    return 0;
}

/****************************************************************************\
 * int debugExecuteFor( ulong num )
 *
 * desc - runs a specified number of opcodes.
 *
 * in   - 'num' specifies the number of opcodes to run.
 *
 * out  - 'num' r3000 opcodes have been run.
 *
 * !!! this is really messed up.  it always executes 47 opcodes for some
 *     reason.  I think there's a loose pointer somewhere else that screws
 *     this function up.
 * !!! note also that delay slots are not counted as opcodes because they do
 *     not have epilog code compiled for them.  without the epilog code, they
 *     do not count themselves as opcodes.
\****************************************************************************/
int     debugExecuteFor(    ulong    num    )
{
    ulong    j;     // lcv.

    pexMesg( stderr, "debug : execute %u opcodes.\n", num );
    for ( j = 0; j < num; j++ )
    {
        // debug message.
        pexMesg( stderr, "cpu start %u / %u\n", j, num );
        cpuStart();
    }
    debugDisasmOfs = 0;

    return 0;
}

/****************************************************************************\
 * ulong debugCalcOverhead( void )
 *
 * desc - attempts to determine the minimum overhead the simplest epilog
 *  debug code (normal execution class) uses.
 *
 * in   - host must be a GenuineIntel.
 *
 * out  - returns minimum debug overhead in cycles.
\****************************************************************************/
ulong   debugCalcOverhead(  void    )
{
    ulong   j;
    ulong   overhead;

    StartTSC();
    for ( j = 0; j < 10000; j++ )
        mipsCNEPIcode();
    EndTSC();
    overhead = TSC / 10000;
    pexMesg( stderr, "minimum debugging overhead is %u cycles.\n", overhead );

    return overhead;
}

/****************************************************************************\
 * int debugFinalReport( void )
 *
 * desc - produces the final debugger report to the logfile.
 *
 * in   - debugger has finished.
 *
 * out  - final debugger report has been appended to logfile.
\****************************************************************************/
int     debugFinalReport(   void    )
{
    ulong   avg;
    float   speed;

    // r3000 profiling only works on GenuineIntel hosts.
    if ( hostIntel )
    {
        avg = cpuExecs ? (cpuCycles / cpuExecs - debugOverhead) : 0;
        speed = cpuExecs ? (float) hostSpeed / avg : 0;
        pexMesg( stderr, "%u MIPS opcodes were executed in %u cpu starts.\n",
            cpuExecs, cpuStarts );
        pexMesg( stderr, "average r3000a performance : %u c/i, %1.2fMhz\n",
            avg, speed );
    }

    pexMesg( stderr, "maximum i86 memory usage : %u Kb\n",
        memoryIntelSize / 1024 );

    pexMesg( stderr, "%u cpu watch events occurred.\n", cpuWatch );
    pexMesg( stderr, "%u unimplemented MIPS opcodes were encountered.\n", cpuNA );
    pexMesg( stderr, "%u unimplemented hardware registers were accessed.\n", memoryRegisterNA );
    return 0;
}

/****************************************************************************/
/* end of debug.c                                                           */
/****************************************************************************/
