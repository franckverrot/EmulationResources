/****************************************************************************\
 * kernel_c.c                                                               *
 * psx library c macrocode for PEX-1000.  work in progress and disarray.    *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include "general.h"
#include "pex.h"
#include "cpu.h"
#include "memory.h"
#include "kernel.h"
#include "cdrom.h"

/****************************************************************************\
 * void kernelNI( void )
 *
 * desc - default PEX-1000 system call handler.  reports call is not done yet.
 *
 * in   - should never be called directly.  kernel?0 handlers should call it.
 *
 * out  - message written out to log file.
\****************************************************************************/
void    kernelNI(   void    )
{
    pexMesg( stderr, "call to unimplemented system call.\n" );
    return;
}

/****************************************************************************\
 * kernelOpen()
 *
 * desc -
\****************************************************************************/
int     kernelOpen( void )
// ( char    *name, int     mode    )
{
/*    char    buf[ 80 ];
    FILE*   handle;

    strcpy( buf, cdromLetter );
    strcat( buf, ":" );
    strcat( buf, (char*) ptr1 );

    handle = fopen( name, "r" );

    return (int) handle;
*/
    return 0;
}

/****************************************************************************/
/* kernelLseek()                                                            */
/****************************************************************************/
int     kernelLseek( void )
// ( int fd, int offset, int whence  )
{
//    return fseek( (FILE*) fd, offset, whence );
    return 0;
}

/****************************************************************************/
/* kernelRead()                                                             */
/****************************************************************************/
int     kernelRead( void )
// ( int fd, char *buf, int nbytes  )
{
//    return fread( buf, 1, nbytes, (FILE*) fd );
    return 0;
}

/****************************************************************************/
/* kernelWrite()                                                            */
/****************************************************************************/
int     kernelWrite( void )
// ( int fd, char *buf, int nbytes  )
{
//    return fwrite( buf, 1, nbytes, (FILE*) fd );
    return 0;
}

/****************************************************************************/
/* kernelClose()                                                            */
/****************************************************************************/
void    kernelClose( void )
// ( int fd )
{
//    fclose( (FILE*) fd );
    return;
}

/****************************************************************************/
/* kernelIoctl()                                                            */
/****************************************************************************/
int     kernelIoctl( void )
// ( int fd,  int cmd, int arg )
{
    return 0;
}

/****************************************************************************/
/* kernelExit()                                                             */
/****************************************************************************/
void    kernelExit( void    )
{
    //assemble ret into code.
    return;
}

/****************************************************************************/
/* kernelSys_b0_39()                                                        */
/****************************************************************************/
void    kernelSys_b0_39(    void    )
{
    return;
}



/****************************************************************************\
 * end of kernel_c.c                                                        *
\****************************************************************************/
