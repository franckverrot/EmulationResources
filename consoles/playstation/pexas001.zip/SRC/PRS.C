/****************************************************************************/
/* prs.c                                                                    */
/* creates pex rom support files from sources.                              */
/****************************************************************************/
/* This source code is part of the pex Sony Playstation emulator project.   */
/* Copyright 1997 Geoffrey Wossum, all rights reserved.                     */
/* This version of the pex source code is NOT FOR DISTRIBUTION.             */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "general.h"
#include "rom.h"

/****************************************************************************/
/* global data                                                              */
/****************************************************************************/
char    prsDelimit[]        = " =,{}\n";
char    prsRomDirective[]   = "name";
char    prsIdDirective[]    = "id";
char    prsModDirective[]   = "mod";

/****************************************************************************/
/* prsGetId()                                                               */
/****************************************************************************/
int     prsGetId(   romSupportHeader    *header,
                    FILE                *source,
                    char                *line,
                    int                 *linenum    )
{
    char        *info;
    romIdHeader idheader;
    uchar       buffer[ 256 ];
    int         bufpos;
    char        name[ 13 ];
    FILE        *idfile;

    info = strtok( NULL, prsDelimit );
    idheader.idPtr = strtoul( info, NULL, 16 );
    info = strtok( NULL, prsDelimit );
    idheader.idLen = strtoul( info, NULL, 16 );

    bufpos = 0;
    while ( bufpos < idheader.idLen )
    {
        info = strtok( NULL, prsDelimit );
        while ( info == NULL )
        {
            (*linenum)++;
            fgets( line, 158, source );
            if ( feof( source ) )
            {
                printf( "unexpected end of file.\n" );
                exit( 1 );
            }
            info = strtok( line, prsDelimit );
        }
        buffer[ bufpos ] = (uchar) strtoul( info, NULL, 16 );
        bufpos++;
    }

    sprintf( name, "%d.id", header->idStrings );
    idfile = fopen( name, "wb" );
    fwrite( &idheader, 1, sizeof( idheader ), idfile );
    fwrite( buffer, 1, idheader.idLen, idfile );
    fclose( idfile );

    (header->idStrings)++;
    header->modPtr += sizeof( idheader ) + idheader.idLen;

    return 0;
}

/****************************************************************************/
/* prsGetMod()                                                              */
/****************************************************************************/
int     prsGetMod(  romSupportHeader    *header,
                    FILE                *source,
                    char                *line,
                    int                 *linenum    )
{
    char            *info;
    romModHeader    modheader;
    char            buffer[ 256 ];
    int             bufpos;
    uchar           name[ 13 ];
    FILE            *modfile;

    info = strtok( NULL, prsDelimit );
    modheader.modPtr = strtoul( info, NULL, 16 );
    info = strtok( NULL, prsDelimit );
    modheader.modLen = strtoul( info, NULL, 16 );

    bufpos = 0;
    while ( bufpos < modheader.modLen )
    {
        info = strtok( NULL, prsDelimit );
        while ( info == NULL )
        {
            (*linenum)++;
            fgets( line, 158, source );
            if ( feof( source ) )
            {
                printf( "unexpected end of file.\n" );
                exit( 1 );
            }
            info = strtok( line, prsDelimit );
        }
        buffer[ bufpos ] = (uchar) strtoul( info, NULL, 16 );
        bufpos++;
    }

    sprintf( name, "%d.mod", header->modStrings );
    modfile = fopen( name, "wb" );
    fwrite( &modheader, 1, sizeof( modheader ), modfile );
    fwrite( buffer, 1, modheader.modLen, modfile );
    fclose( modfile );

    (header->modStrings)++;

    return 0;
}

/****************************************************************************/
/* prsProcessSource()                                                       */
/****************************************************************************/
int     prsProcessSource(   romSupportHeader    *header,
                            FILE                *source )
{
    char    line[ 160 ];
    int     linenum = 0;
    char    *directive;

    strcpy( header->id, romSupportId );
    header->idStrings = 0;
    header->idPtr = sizeof( romSupportHeader );
    header->modStrings = 0;
    header->modPtr = sizeof( romSupportHeader );

    while ( !feof( source ) )
    {
        linenum++;
        if ( fgets( line, 158, source ) == NULL )
            continue;
        directive = strtok( line, prsDelimit );

        if ( !strcmpi( line, prsRomDirective ) )
        {
            directive = strtok( NULL, prsDelimit );
            if ( ( directive == NULL ) || ( strlen( directive ) > 29 ) )
            {
                printf( "bad rom name directive at line %d.\n", linenum );
                exit( 1 );
            }
            strcpy( header->romName, directive );
        }
        else if ( !strcmpi( directive, prsIdDirective ) )
        {
            prsGetId( header, source, line, &linenum );
        }
        else if ( !strcmpi( directive, prsModDirective ) )
        {
            prsGetMod( header, source, line, &linenum );
        }
    }

    return 0;
}

/****************************************************************************/
/* prsWriteSupport()                                                        */
/****************************************************************************/
int     prsWriteSupport(    romSupportHeader    *header,
                            FILE                *support    )
{
    int     j;
    char    buf[ 1024 ];
    int     bufsize;
    char    name[ 13 ];
    FILE    *cfil;

    fwrite( header, 1, sizeof( romSupportHeader ), support );

    for ( j = 0; j < header->idStrings; j++ )
    {
        sprintf( name, "%d.id", j );
        cfil = fopen( name, "rb" );
        bufsize = fread( buf, 1, sizeof( buf ), cfil );
        fclose( cfil );
        fwrite( buf, 1, bufsize, support );
        remove( name );
    }

    for ( j = 0; j < header->modStrings; j++ )
    {
        sprintf( name, "%d.mod", j );
        cfil = fopen( name, "rb" );
        bufsize = fread( buf, 1, sizeof( buf ), cfil );
        fclose( cfil );
        fwrite( buf, 1, bufsize, support );
        remove( name );
    }

    return 0;
}

/****************************************************************************/
/* prsReport                                                                */
/****************************************************************************/
int     prsReport(  char                *source,
                    char                *support,
                    romSupportHeader    *header )
{
    printf( "\n%s created from %s\n", support, source );
    printf( "rom name  = %s\n", header->romName );
    printf( "# of ids  = %d\n", header->idStrings );
    printf( "# of mods = %d\n", header->modStrings );
    return 0;
}

/****************************************************************************/
/* main()                                                                   */
/****************************************************************************/
int main( int argc, char *argv[] )
{
    FILE                *source;
    FILE                *support;
    romSupportHeader    header;

    printf( "\nprs - utility to create pex rom support files from source.\n" );
    printf( "1997 Geoffrey Wossum (aka Maxon)\n" );

    if ( argc != 3 )
    {
        printf( "usage : prs <source file input> <support file output>\n" );
        exit( 1 );
    }

    source = fopen( argv[ 1 ], "rt" );
    if ( source == NULL )
    {
        printf( "unable to open %s\n", argv[ 1 ] );
        exit( 1 );
    }

    prsProcessSource( &header, source );

    fclose( source );
    support = fopen( argv[ 2 ], "wb" );
    if ( support == NULL )
    {
        printf( "unable to create %s\n", argv[ 2 ] );
        exit( 1 );
    }

    prsWriteSupport( &header, support );
    fclose( support );

    prsReport( argv[ 1 ], argv[ 2 ], &header );
    return 0;
}


/****************************************************************************/
/* end of prs.c                                                             */
/****************************************************************************/
