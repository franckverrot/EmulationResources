/****************************************************************************\
 * compile.c                                                                *
 * recompile routines for converting R3000A code to Intel code.             *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include "pex.h"
#include "general.h"
#include "memory.h"
#include "cpu.h"
#include "linkdata.h"
#include "mips.h"
#include "intel.h"
#include "compile.h"
#include "profile.h"

/****************************************************************************\
 * global data.                                                             *
\****************************************************************************/
char    compilerVersion[] = "v0.3 (cold warrior)";

/****************************************************************************\
 *  uchar *compilerCompile( ulong psxptr, ulong len )
 *
 *  desc:
 *  recompiles R3000A code into Intel code.
 *  this is the only compiler routine that should be called outside of the
 *  compile module.
 *
 *  in  :
 *  psxptr - psx pointer to the R3000A code to be recompiled into Intel code.
 *  len    - length in bytes of R3000A code to be recompiled into Intel code.
 *
 *  out :
 *  @return - pointer to the recompiled Intel code.
\****************************************************************************/
uchar   *compilerCompile(   ulong   psxptr,
                            ulong   len )
{
    char    *intelptr;
    ulong   size;

    pexMesg( stderr, "compiling %xh byte section of MIPS code at %xh (%xh).\n",
        len, psxptr, memoryConvert( psxptr ) );

    // get memory for x86 code.
    intelptr = compilerPrepare( psxptr, len );
    if ( intelptr == NULL )
        pexError( "Unable to reserve memory for recompiled code." );

    // perform compiler passes.
    size = compilerEmitPass( psxptr, intelptr, len );
    compilerLinkPass( psxptr, intelptr, len );

    pexMesg( stderr, "recompiled code size : %x bytes.\n", size );
    memoryIntelResize( intelptr, size + 1024 );

    return intelptr;
}

/****************************************************************************\
 *  uchar *compilerPrepare( ulong psxptr, ulong len )
 *
 *  desc:
 *  prepares the memory structures for the recompiler.
 *  this function must be compiled before any code is recompiled.
 *  this function should never be called outside of the compile module.
 *
 *  in  :
 *  psxptr - psx pointer to the R3000A code to be recompiled into Intel code.
 *  len    - length in bytes of R3000A code to be recompiled into Intel code.
 *
 *  out :
 *  @return - pointer to the memory allocated for the Intel code to be placed.
 *  the translate table has been prepared for the recompiler.
\****************************************************************************/
uchar   *compilerPrepare(   ulong   psxptr,
                            ulong   len )
{
    uchar   *intelptr;
    ulong   *xlatptr;
    ulong   j;
    FILE    *bin;

    // make sure 'psxptr' can is in an executable area.
    xlatptr = memoryXlat( psxptr );
    bin = fopen( "compile.bin", "wb" );
    fwrite( memoryConvert( psxptr ), 1, len, bin );
    fclose( bin );
    if ( xlatptr == NULL )
        pexError( "Attempt to compile in illegal psx address space." );

    // allocate memory for x86 code.
    intelptr = (uchar*) memoryAllocIntel( len * compileIntelFactor,
        psxptr, psxptr + len );

    return intelptr;
}


/****************************************************************************\
 *  ulong compilerEmitPass( ulong psxptr, uchar *intelptr, ulong len )
 *
 *  desc:
 *  takes R3000A code and emits Intel x86 code.
 *  this should be called as the second pass in recompiling.
 *  this should not be called from outside the compile module.
 *
 *  in  :
 *  psxptr   - psx pointer to R3000A code to be recompiled.
 *  intelptr - points to where to place Intel code.
 *  len      - length in bytes of R3000A code to be recompiled.
 *
 *  out :
 *  @return - length in bytes of newly emitted Intel x86 code.
 *  R3000A code starting at the psx memory pointer 'psxptr' of length in bytes
 *  'len' has been recompiled into Intel x86 code starting at 'intelptr'.
\****************************************************************************/
ulong   compilerEmitPass(   ulong   psxptr,
                            uchar   *intelptr,
                            ulong   len )
{
    ulong       j;          // general pupose lcv.
    ulong       *mipsptr;   // pointer to a mips opcode.
    ulong       *xlatptr;   // pointer to an xlat entry.
    mipsInstr   opinfo;     // decoded mips opcode information.
    uchar       *startptr;  // marks where we started compiling x86 code to.

    startptr = intelptr;
    mipsptr = memoryConvert( psxptr );
    xlatptr = memoryXlat( psxptr );

    for ( j = 0; j < len / 4; j++ )
    {
        // set xlat address for opcode to current intelptr.
        *xlatptr = (ulong) intelptr;
        // decode mips opcode at current mipsptr.
        mipsDecode( *mipsptr, &opinfo );

        // emit main body and epilog based on execution classes.
        if ( opinfo.instr & classDelay )
        {
            intelptr = compilerEmit( mipsptr + 1, psxptr + 4,  intelptr );
            intelptr = compilerEmit( mipsptr, psxptr, intelptr );
            intelptr = compilerEmitEpilog( mipsptr, psxptr, intelptr );
        }
        else if ( opinfo.instr & classLikely )
        {
            intelptr = compilerEmit( mipsptr, psxptr, intelptr );
            intelptr = compilerEmit( mipsptr + 1, psxptr + 4, intelptr );
            intelptr = compilerEmitEpilog( mipsptr, psxptr, intelptr );
        }
        else
        {
            intelptr = compilerEmit( mipsptr, psxptr, intelptr );
            intelptr = compilerEmitEpilog( mipsptr, psxptr, intelptr );
        }

        // increment all pointers.
        xlatptr++;
        mipsptr++;
        psxptr += 4;
    }

    pexMesg( stderr, "compile pass 1 complete.\n" );
    return (ulong) (intelptr - startptr);
}

/****************************************************************************\
 *  uchar *compilerEmit( ulong psxptr, uchar *intelptr )
 *
 *  desc:
 *  emits a sequence based on the translate table chain starting at psxptr.
 *
 *  in  :
 *  psxptr   - psx pointer to MIPS instruction being recomipled.
 *  intelptr - points to where to assemble the corresponding x86 code.
 *
 *  out :
 *  @return - points to where next x86 code should be emitted to.
 *  all MIPS opcodes in the compile chain starting at 'psxptr' have been
 *  had Intel x86 code emitted for them.
\****************************************************************************/
uchar   *compilerEmitIntel( ulong       *mipsptr,
                            ulong       psxptr,
                            uchar       *intelptr,
                            void        **code[],
                            linkMIPS    **data[]    )
{
    void        *codeptr;   // pointer to x86-mips macrocode.
    linkMIPS    *dataptr;   // pointer to x86-mips linkdata.
    mipsInstr   opinfo;     // decoded mips opcode.
    ulong       *regptr;    // temporary variable used in register emitters.
    ulong       buffer;     // temporary variable used in unsigned emitters.
    long        sign;       // temporary variable used in signed emitters.

    // decode opcode (again).
    mipsDecode( *mipsptr, &opinfo );

    // set up macrocode and linkdata pointers.
    if ( opinfo.instr & classOpcode )
    {
        codeptr = code[ 0 ][ opinfo.instr & classMask ];
        dataptr = data[ 0 ][ opinfo.instr & classMask ];
    }
    else if ( opinfo.instr & classRegimm )
    {
        codeptr = code[ 1 ][ opinfo.instr & classMask ];
        dataptr = data[ 1 ][ opinfo.instr & classMask ];
    }
    else if ( opinfo.instr & classSpecial )
    {
        codeptr = code[ 2 ][ opinfo.instr & classMask ];
        dataptr = data[ 2 ][ opinfo.instr & classMask ];
    }

    // copy generic mips-x86 macrocode to intelptr.
    memcpy( intelptr, codeptr, dataptr->ln );

    // mips-x86 operand emitters.
    // these fit the generic macrocode to each specific opcode by using
    // the mips-x86 linkdata and the decoded mips opcode.

    // emit pointer to r3000 register in RS field.
    if ( dataptr->rs != NA )
    {
        regptr = cpuGPR + opinfo.rs;
        memcpy( intelptr + dataptr->rs, &regptr, 4 );
    }

    // emit pointer to r3000 register in RT field.
    if ( dataptr->rt != NA )
    {
        regptr = cpuGPR + opinfo.rt;
        memcpy( intelptr + dataptr->rt, &regptr, 4 );
    }

    // emit pointer to r3000 register in RD field.
    if ( dataptr->rd != NA )
    {
        regptr = cpuGPR + opinfo.rd;
        memcpy( intelptr + dataptr->rd, &regptr, 4 );
    }

    // emit a SIGNED 16bit constant value from mips opcode.
    if ( dataptr->ls != NA )
    {
        sign = (long) ( (short) opinfo.lo );
        memcpy( intelptr + dataptr->ls, &sign, 4 );
    }

    // emit an UNSIGNED 16bit constant value from mips opcode.
    if ( dataptr->lz != NA )
        memcpy( intelptr + dataptr->lz, &(opinfo.lo), 4 );

    // emit shift field from mips opcode.
    if ( dataptr->sa != NA )
        memcpy( intelptr + dataptr->sa, &(opinfo.sa), 4 );

    // emit "large" 27bit field from mips opcode.
    if ( dataptr->la != NA )
        memcpy( intelptr + dataptr->la, &(opinfo.la), 4 );

    // emit PC (current psx space address).
    if ( dataptr->pc != NA )
        memcpy( intelptr + dataptr->pc, &psxptr, 4 );

    // emit psx pointer to jump destination.
    if ( dataptr->np != NA )
    {
        buffer = mipsCalcJump( psxptr, &opinfo );
        memcpy( intelptr + dataptr->np, &buffer, 4 );
    }
        
    return (intelptr + dataptr->ln);
}

/****************************************************************************\
 *  ulong compilerLinkPass( ulong psxptr, char *intelptr, ulong len )
 *
 *  desc:
 *  links jump offsets in Intel code because jump offsets can not always be
 *  resolved during the emit pass.
 *  this should be used as the third pass in recompiling.
 *  this function should not be called from outside of the compile module.
 *
 *  in  :
 *  psxptr   - psx pointer of R3000A code being recompiled.
 *  intelptr - points to where Intel code has been emitted.
 *  len      - length in bytes of R3000A code being recompiled.
 *
 *  out :
 *  @return - always 0.
 *  all jump offsets in newly emitted Intel x86 code have been properly linked.
\****************************************************************************/
ulong   compilerLinkPass(   ulong   psxptr,
                            char    *intelptr,
                            ulong   len )
{
/*--------------------------------------------------------------------------*\
 -  Uh-oh, I don't have the link pass in here right now!
 -  without either a link pass, or some changes to the epilog macro code,
 -  pex won't run out of debug mode!  of course, it doesn't even try to
 -  run MIPS code out of debug mode right now!
\*--------------------------------------------------------------------------*/
    pexMesg( stderr, "compile pass 2 complete.\n" );
    return 0;
}

/****************************************************************************\
 *  void UNIBRANCH( void )
 *
 *  desc:
 *  this is used as a dummy function used by the MIPS-x86 library.
 *  this function should never be called.  period.
\****************************************************************************/
void    UNIBRANCH(  void    )
{
    return;
}

/****************************************************************************/
/* end of compile.c                                                         */
/****************************************************************************/
