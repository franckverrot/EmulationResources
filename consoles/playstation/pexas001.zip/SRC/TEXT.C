/****************************************************************************\
 * text.c                                                                   *
 * some display functions for pex                                           *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <i86.h>
#include <stdio.h>
#include "general.h"

/****************************************************************************\
 * macros.                                                                  *
\****************************************************************************/
#define VIDEOINT int386(0x10, &regs, &regs);

/****************************************************************************\
 * global data.                                                             *
\****************************************************************************/
static  short   textAttrib = 0x1700;

/****************************************************************************\
 * void text80x50( void )
 *
 * desc - sets up an 80x50 text mode.
 *
 * in   - standard vga should be active display system.  that is, a 3Dfx
 *  should not be active.
 *
 * out  - system is set in a 80x50 "standard" text mode.
\****************************************************************************/
/* borrowed from midas player source code. */
void    text80x50(  void    )
{
    static union REGS  regs;

    regs.w.ax = 3;
    VIDEOINT

    regs.w.ax = 0x0500;
    VIDEOINT

    regs.w.ax = 0x1202;
    regs.h.bl = 0x30;
    VIDEOINT

    regs.w.ax = 3;
    VIDEOINT

    regs.w.ax = 0x1112;
    regs.h.bl = 0;
    VIDEOINT

    *((uchar*) 0x487) = (*((uchar*) 0x487)) | 1;

    regs.h.ah = 1;
    regs.w.cx = 0x0600;
    VIDEOINT

    *((uchar*) 0x487) = (*((uchar*) 0x487)) & 0xFE;

    outpw(0x3D4, 0x0814);

    return;
}

/****************************************************************************\
 * void text80x25( void )
 *
 * desc - sets up the standard 80x25 vga mode 03h vido mode.
 *
 * in   - 3Dfx should not be active.
 *
 * out  - system is in mode 03h 80x25 vga text mode.
\****************************************************************************/
void    text80x25(  void    )
{
    union REGS  regs;

    regs.w.ax = 3;
    VIDEOINT
}

/****************************************************************************\
 * int textWrite( int y, int x, char *str )
 *
 * desc - writes the NUL terminated 'str' out to text memory located at
 *  (x, y).
 *  the upper-left hand corner of the screen is (0,0).
 *  this routine is hardcoded to 80 columns.
 *  the following control sequences may be used in 'str' :
 *  0xFF 0xNN - NN is set to the default text attribute.
 *
 * in   - 'y' is the column to start writing 'str' to.
 *        'x' is the row to start writing 'str' to.
 *        'str' is the string to write out to text memory.
 *
 * out  - 'str' has been written to text memory starting at (x,y).  if no
 *  color set code sequence was given at beginning of 'str', color will
 *  default to color used in last textWrite call.  the default color at the
 *  of textWrite will be default color for next call to textWrite.
 *  function return value is always 0.
\****************************************************************************/
int     textWrite(  int     y,
                    int     x,
                    char    *str    )
{
    ushort          *page_ptr;

    page_ptr = (ushort*) ( 0xb8000 + (y * 160) + (x * 2) );

    while ( *str != '\0' )
    {
        switch ( *str )
        {
            case 0xff :
            {
                str++;
                textAttrib = (*str) << 8;
                break;
            }
            default :
            {
                *page_ptr = textAttrib | *str;
                page_ptr++;
                break;
            }
        }
        str++;
    }
    return 0;
}

/****************************************************************************\
 * int textPut( int y, int x, char *str )
 *
 * desc - writes the NUL terminated 'str' out to text memory located at
 *  (x, y).
 *  the upper-left hand corner of the screen is (0,0).
 *  this routine is hardcoded to 80 columns.
 *  unlike textWrite, no control sequences are processed in 'str'.
 *
 * in   - 'y' is the column to start writing 'str' to.
 *        'x' is the row to start writing 'str' to.
 *        'str' is the string to write out to text memory.
 *
 * out  - 'str' has been written to text memory starting at (x,y).  color
 *  will be last color set in a textWrite call.
 *  function return value is always 0.
\****************************************************************************/
int     textPut(    int     y,
                    int     x,
                    char    *str    )
{
    ushort          *page_ptr;

    page_ptr = (ushort*) ( 0xb8000 + (y * 160) + (x * 2) );

    while ( *str != '\0' )
    {
        *page_ptr = textAttrib | *str;
        page_ptr++;
        str++;
    }
    return 0;
}

/****************************************************************************\
 * int textFlood( char attrib )
 *
 * desc - floods text memory with 'attrib'.
 *
 * in   - 'attrib' is the color to flood the text memory with.
 *
 * out  - text memory has been flooded with 'attrib'.  assumes a 80x50 mode.
 *  return value is always 0.
\****************************************************************************/
int     textFlood(  char attrib )
{
    int     j;
    ushort  *page_ptr;
    ushort  atr;

    page_ptr = (ushort*) 0xb8000;
    atr = attrib << 8;
    for ( j = 0; j < 80 * 50; j++ )
    {
        *page_ptr = atr;
        page_ptr++;
    }


    return 0;
}

/****************************************************************************\
 * int textDump( char *name )
 *
 * desc - dumps 80x50 text memory to a file for screen shot purposes.
 *
 * in   - 'name' is a valid file name to dump the memory to.
 *
 * out  - text memory has been dumped to a file named 'name'.  no error
 *  checking is performed.  this can fail, but you'll never know it.
 *  return value is always 0.
\****************************************************************************/
int     textDump(   char    *name   )
{
    FILE    *fil;

    fil = fopen( name, "w" );
    fwrite( ((void*) 0xb8000), 1, 8000, fil );
    fclose( fil );
    return 0;
}

/****************************************************************************\
 * end of text.c                                                            *
\****************************************************************************/
