/****************************************************************************\
 * cdrom.c                                                                  *
 * routines for emulating psx cdrom hardware.                               *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <i86.h>        // this is Watcom specific.
#include <string.h>
#include <direct.h>
#include "general.h"
#include "pex.h"
#include "cdrom.h"
#include "kbd.h"
#include "kernel.h"
#include "cpu.h"

/****************************************************************************\
 * global data                                                              *
\****************************************************************************/
char    mscdexDriveList[ 20 ] = ""; // holds list of all cdrom drives.
char    cdromLetter[ 5 ];           // letter of cdrom to use for everything.
int     cdromNumber;                // the id number of cdrom to use.

/****************************************************************************\
 * uint mscdexVersion( void )                                               *
 *                                                                          *
 * desc - gets the mscdex version number.                                   *
 *                                                                          *
 * in   - nothing.                                                          *
 *                                                                          *
 * out  - returns mscdex version number : hi byte = major version           *
 *                                        lo byte = minor version.          *
 *        returns 0 if no mscdex was found.                                 *
\****************************************************************************/
uint    mscdexVersion(  void    )
{
    union REGS  regs;
    uint        ver;

    regs.w.ax = 0x150c;
    regs.w.bx = 0;
    MSCDEXINT( regs );
    ver = 0;

    if ( regs.w.bx == 0 )
        ver = 0x0100;
    else
        ver = regs.w.bx;

    return ver;
}

/****************************************************************************\
 * char *mscdexDrives( char *list )                                         *
 *                                                                          *
 * desc - finds all cdrom drives in a system.                               *
 *                                                                          *
 * in   - 'list' is an array to stick letters of system cdrom drives in.    *
 *                                                                          *
 * out  - 'list' is a string containing all cdrom drive letters.  for       *
 *  instance, if a system has a D and an E cdrom driver 'list' contains     *
 *  "DE".  'list' == "" if no cdrom drives in system.                       *
 *  return value is always equal to 'list'.                                 *
\****************************************************************************/
char    *mscdexDrives(  char    *list   )
{
    union REGS  regs;
    int         j;
    char        letter;

    regs.w.ax = 0x1500;
    regs.w.bx = 0;
    MSCDEXINT( regs );
    if ( regs.w.bx == 0 )
        pexError( "no cdrom units were detected.\n" );

    letter = regs.w.cx + 'A';
    for ( j = 0; j < regs.w.bx; j++ )
    {
        list[ j ] = letter;
        letter++;
    }
    list[ j ] = '\0';

    return list;
}

/****************************************************************************\
 * int cdromChoose( char *list, char *letter, int *num )                    *
 *                                                                          *
 * desc - chooses which cdrom in a system to use.                           *
 *                                                                          *
 * in   - 'list' is pointer to cdrom drive listed created by mscdexDrives.  *
 *        'letter' is a pointer to store drive letter cdromChoose selects.  *
 *        'num' is a pointer to an int to store drive id cdromChoose sel.   *
 *                                                                          *
 * out  - always returns 0.                                                 *
 *  if system has only one cdrom, it is chosen automatically.               *
 *  if system has more than one cdrom, the first one is chosen automatic-   *
 *  ally, unless pex was started with the '/config' switch.  in this case,  *
 *  the user is prompted to choose which cdrom they want to use.            *
\****************************************************************************/
int     cdromChoose(    char    *list,
                        char    *letter,
                        int     *num    )
{
    int     j;

    if ( pexAutoConfig || (strlen( list ) == 1) )
    {
        // selects first drive (or only drive) in a system.
        *letter = *list;
        letter[ 1 ] = '\0';
        *num = 0;
        return 0;
    }

    // prompt user for a drive.
    do
    {
//        kbdFlush();
        fflush( stdin );
        printf( "Please choose cdrom unit to use (%s) - ", list );
        fgets( letter, 10, stdin );
        strupr( letter );
        j = 0;
        while ( (j < strlen( list )) && (list[ j ] != letter[ j ]) )
            j++;
    }
    while ( j >= strlen( list ) );

    // select drive user chose.
    *letter = list[ j ];
    letter[ 1 ] = '\0';
    *num = j;
    return 0;
}
 
/****************************************************************************\
 * int cdromInit( void )                                                    *
 *                                                                          *
 * desc - initializes pcx cdrom interface.                                  *
 *                                                                          *
 * in   - nothing.                                                          *
 *                                                                          *
 * out  - pcx cdrom interface has been initialzed.  any cdrom function      *
 *  can be used after a call to cdromInit.                                  *
\****************************************************************************/
int cdromInit(  void    )
{
    uint    ver;        // mscdex version

    pexMesg( stderr, "initializing cdrom interface.\n" );

    // make sure were using at least MSCDEX 2.10
    ver = mscdexVersion();
    if ( ver < 0x20a )
        pexError( "Requires MSCDEX 2.10 or higher." );
    fprintf( stderr, "found mscdex %d.%d\n", hi( ver ), lo( ver ) );

    // find and select cdrom unit.
    mscdexDrives( mscdexDriveList );
    fprintf( stderr, "found following cdrom units - %s\n", mscdexDriveList );
    cdromChoose( mscdexDriveList, cdromLetter, &cdromNumber );
    fprintf( stderr, "using cdrom unit %s.\n", cdromLetter );

    return 0;
}

/****************************************************************************\
 * int cdromDefine( void )                                                  *
 *                                                                          *
 * desc - this initializes the cdrom device for PEX-1000.  work in progress.*
 *  only PEX-1000 should call this.                                         *
 *                                                                          *
 * in   - basic PEX-1000 kernel initialization should have occurred.        *
 *                                                                          *
 * out  - a cdrom IO device driver has been constructed.                    *
\****************************************************************************/
int     cdromDefine(    void    )
{
    IODDtbl     *iodd;              // pc pointer to cdrom IO device driver.
    char        name[] = "cdrom";   // name of cdrom device.
    char        desc[] = "CD-ROM";  // description of cdrom device.

    // allocate memory for IO device driver.
    iodd = (IODDtbl*) memoryConvert( kernelAllocIODD() );

    // setup up fields of IO device driver.
    iodd->dev_name = (char*) kernelPoolAlloc( sizeof( name ) );
    memcpy( (void*) memoryConvert( iodd->dev_name ), name, sizeof( name ) );
    iodd->devflag = 14;         //from an scph-1000 rom.
    iodd->blockSize = 2048;
    iodd->dev_desc = (char*) kernelPoolAlloc( sizeof( desc ) );
    memcpy( (void*) memoryConvert( iodd->dev_desc ), desc, sizeof( desc ) );
    iodd->init = &cdInit;
    iodd->open = &cdOpen;
    iodd->x1 = &cdInit;  //from an scph-1000 rom.
    iodd->close = &cdClose;
    iodd->ioctl = &cdIoctl;
    iodd->read = &cdRead;
    iodd->write = &cdWrite;
    iodd->erase = &cdErase;
    iodd->undelete = &cdUndelete;
    iodd->firstfile = &cdFirstFile;
    iodd->nextfile = &cdNextFile;
    iodd->format = &cdFormat;
    iodd->cd = &cdCd;
    iodd->rename = &cdRename;
    iodd->deinit = &cdDeinit;
    iodd->x2 = &cdInit;  //from an scph-1000 rom.

    return 0;
}

/****************************************************************************\
 * void cdInit( void )                                                      *
 *                                                                          *
 * desc - INIT function psx IO device driver references.                    *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdInit( void    )
{
    char    path[ 8 ];

    strcpy( path, cdromLetter );
    strcat( path, ":\\" );
    chdir( path );
    cpuV0 = 0;
    return;
}

/****************************************************************************\
 * void cdOpen( void )                                                      *
 *                                                                          *
 * desc - OPEN function psx IO device driver references.                    *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdOpen( void    )
{
    return;
}

/****************************************************************************\
 * void cdClose( void )                                                     *
 *                                                                          *
 * desc - CLOSE function psx IO device driver references.                   *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdClose(    void    )
{
    return;
}

/****************************************************************************\
 * void cdIoctl( void )                                                     *
 *                                                                          *
 * desc - IOCTL function psx IO device driver references.                   *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdIoctl(    void    )
{
    return;
}

/****************************************************************************\
 * void cdRead( void )                                                      *
 *                                                                          *
 * desc - READ function psx IO device driver references.                    *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdRead( void    )
{
    return;
}

/****************************************************************************\
 * void cdWrite( void )                                                     *
 *                                                                          *
 * desc - WRITE function psx IO device driver references.                   *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdWrite(    void    )
{
    pexError( "can not write to cdrom device!" );
    return;
}

/****************************************************************************\
 * void cdErase( void )                                                     *
 *                                                                          *
 * desc - ERASE function psx IO device driver references.                   *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdErase(    void    )
{
    pexError( "can not erase on cdrom device!" );
    return;
}

/****************************************************************************\
 * void cdUndelete( void )                                                  *
 *                                                                          *
 * desc - UNDELETE function psx IO device driver references.                *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdUndelete( void    )
{
    pexError( "can not undelete on cdrom device!" );
    return;
}

/****************************************************************************\
 * void cdFirstFile( void )                                                 *
 *                                                                          *
 * desc - FIRSTFILE function psx IO device driver references.               *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdFirstFile(    void    )
{
    return;
}

/****************************************************************************\
 * void cdNextFile( void )                                                  *
 *                                                                          *
 * desc - NEXTFILE function psx IO device driver references.                *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdNextFile( void    )
{
    return;
}

/****************************************************************************\
 * void cdFormat( void )                                                    *
 *                                                                          *
 * desc - FORMAT function psx IO device driver references.                  *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdFormat(   void    )
{
    pexError( "can not format cdrom device!" );
    return;
}

/****************************************************************************\
 * void cdCd( void )                                                        *
 *                                                                          *
 * desc - CD function psx IO device driver references.                      *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/

void    cdCd(   void    )
{
    return;
}

/****************************************************************************\
 * void cdRename( void )                                                    *
 *                                                                          *
 * desc - RENAME function psx IO device driver references.                  *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdRename(   void    )
{
    return;
}

/****************************************************************************\
 * void cdDeinit( void )                                                    *
 *                                                                          *
 * desc - DEINIT function psx IO device driver references.                  *
 *                                                                          *
 * in   - ???                                                               *
 *                                                                          *
 * out  - ???                                                               *
\****************************************************************************/
void    cdDeinit(   void    )
{
    return;
}

/****************************************************************************\
 * end of cdrom.c                                                           *
\****************************************************************************/
