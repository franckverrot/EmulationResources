/****************************************************************************\
 * pex.c                                                                    *
 * the main driver function for pex.                                        *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <i86.h>        // this is Watcom specific.
#include "general.h"
#include "pex.h"
#include "text.h"
#include "memory.h"
#include "cpu.h"
#include "debug.h"
#include "linkdata.h"
#include "compile.h"
#include "cdrom.h"
#include "mips_lib.h"
#include "midasdll.h"
#include "kernel.h"
#include "profile.h"
#include "kbd.h"
#include "host.h"
#include "dynamap.h"
#include "rom.h"

#ifdef __GLIDE__
#include "voodoo.h"     // this is specific to Glide pex.
#endif

/* prototypes i don't want in "pex.h" */
int parseCL( int, char*[] );
int pexStartUp( void );
int pexShutDown( void );

/****************************************************************************\
 * global data                                                              *
\****************************************************************************/
int     pexDebug        = 0;    // set to 1 if running in debug mode.
int     pexErrorDisp    = 0;    // set to 1 if terminating with an error.
char    *pexErrorMsg    = NULL; // pointer to error message.
int     pexOptions[ pexNumOptions ] = { 0, 1, 0 }; //default options.
char    *pexSwitches[ pexNumSwitches ] =  // the command line switches.
    {   "/debug",
        "/config",
        "/kernel"   };

/****************************************************************************\
 * int parseCL( int argc, char *argv[] )                                    *
 *                                                                          *
 * desc - sets pexOptions based on command line passed in.                  *
 *                                                                          *
 * in   - 'argc' is number of command line arguments.                       *
 *        'argv' is pointer to command line strings.                        *
 *                                                                          *
 * out  - pexOptions[ x ] has been toggled if pexSwitches[ x ] was in argv. *
 *  always returns 0.                                                       *
\****************************************************************************/
int     parseCL(    int     argc,
                    char    *argv[] )
{
    int     j, k;

    for ( j = 1; j < argc; j++ )
    {
        strlwr( argv[ j ] );
        for ( k = 0; k < pexNumSwitches; k++ )
            if ( !strcmp( argv[ j ], pexSwitches[ k ] ) )
                pexOptions[ k ] = !pexOptions[ k ];
    }

    if ( pexOptions[ pexDebugOption ] )
        pexDebug = 1;

    return 0;
}

/****************************************************************************\
 * int pexStartUp( void )                                                   *
 *                                                                          *
 * desc - initializes all psx86 and pcx functions.                          *
 *                                                                          *
 * in   - nothing.                                                          *
 *                                                                          *
 * out  - all psx86 and pcx functions have been initialized and can be used *
 *  after a call to pexStartUp.                                             *
\****************************************************************************/
int     pexStartUp( void    )
{
    // make sure pexShutDown always get shutdown properly.
    atexit( pexShutDown );

    /* start logfile if running in debug mode. */
    if ( pexDebug )
    {
        freopen( PEX_LOG, "w", stderr );
        setbuf( stderr, NULL );
        printf( "pex is running in debug mode.\n" );
        fprintf( stderr, "pex v%s, build %s\n", pex_version, pex_build );
        fprintf( stderr, "using psx86 compiler %s\n", compilerVersion );
        fprintf( stderr, "using psx86 library %s\n", mipsVersion );
        fprintf( stderr, "using psx86 memMap %s\n", memoryVersion );
        fprintf( stderr, "using psx86 kernel %s\n", kernelVersion );
        fprintf( stderr, "using psx86 r3kshell %s\n", cpuVersion );
        fprintf( stderr, "using MIDAS %s\n", MIDASgetVersionString() );

        // setup up linkdata for psx86 compiler in debug mode..
        memcpy( linkCode, linkMainDebugCode, sizeof( linkCode ) );
        memcpy( linkData, linkMainDebugData, sizeof( linkData ) );
        memcpy( linkEpilogCode, linkEpilogDebugCode, sizeof( linkEpilogCode ) );
        memcpy( linkEpilogData, linkEpilogDebugData, sizeof( linkEpilogData ) );
    }
    else
    {
        // setup up linkdata for psx86 compiler in normal mode.
        memcpy( linkCode, linkMainStdCode, sizeof( linkCode ) );
        memcpy( linkData, linkMainStdData, sizeof( linkData ) );
        memcpy( linkEpilogCode, linkEpilogStdCode, sizeof( linkEpilogCode ) );
        memcpy( linkEpilogData, linkEpilogStdData, sizeof( linkEpilogData ) ) ;
    }

    hostCpuCheck();     // check for cpu requirement.

    kbdSaveStatus();    // save status of keyboard lights.
    kbdCLoff();         // turn off caps lock.
    kbdNLoff();         // turn off num lock.
    kbdSLoff();         // turn off scroll lock.
    memoryInit();       // initialize psx86 memory emulation.
    dmaInit();          // initialize psx86 dma services.
    spuInit();          // initialize pcx/psx86 SPU emulation.
    gpuInit();          // initialize pcx/psx86 GPU emulation.
    cdromInit();        // initialize pcx/psx86 cdrom emulation.
    dynamapInit();      // initialize psx86 dynamap for compiler.
    cpuReset();         // reset psx86 r3000 emulation.
    kbdInit();          // initialize pcx keyboard handler.

    if ( pexUseKernel )
    {
        // initialize PEX-1000 kernel if '/kernel' command line switch used.
        pexMesg( stderr, "using PEX-1000 kernel.\n" );
        kernelInit();
    }
    else
    {
        // use a rom image.  default operation.
        pexMesg( stderr, "using SCPH rom image.\n" );
        romLoadImage();
        romPatch();
        compilerCompile( StartRom, memoryROMsize );
    }

#ifdef __GLIDE__
    voodooInit();   // initialize pcx Voodoo interface.
#endif

    return 0;
}


/****************************************************************************\
 * int pexShutDown( void )                                                  *
 *                                                                          *
 * desc - shuts down psx86 and pcx systems.                                 *
 *                                                                          *
 * in   - pexStartup was called before calling this function.               *
 *                                                                          *
 * out  - all psx86 and pcx systems have been shutdown.  no psx86 or pcx    *
 *  calls should be made after a call to pexShutdown.                       *
 *  if pexError is non-zero, pexErrorMesg is display.  otherwise, a splash  *
 *  screen is displayed.                                                    *
\****************************************************************************/
int     pexShutDown(    void    )
{
    kbdDeinit();        // shutdown keyboard handler.
    memoryDeInit();     // free psx86 memory emulation.
    dynamapDeinit();    // remove dynamap routines.
    spuDeinit();        // shutdown pcx SPU emulation.


#ifdef __GLIDE__
    voodooDeinit();     // shutdown pcx Voodoo interface.
#endif
    text80x25();        // go to an 80x25 text mode.

    // display error if pexErrorDisp.
    if ( pexErrorDisp )
    {
        printf( "pex encountered a fatal error.\n" );
        pexMesg( stderr, "pex encountered a fatal error.\n" );
        printf( "%s\n", pexErrorMsg );
        pexMesg( stderr, "%s\n", pexErrorMsg );
    }
    else
    {
        // otherwise do the end splash screen.
        pexEndSplash();
    }


    /* close logfile if in debug mode. */
    if ( pexDebug )
        fclose( stderr );

    kbdRestoreStatus();     // restore keyboard lights.

    return 0;
}

/****************************************************************************\
 * void pexError( char *error )                                             *
 *                                                                          *
 * desc - any part of pex may call pexError when a fatal error occurs.      *
 *                                                                          *
 * in   - 'error' is the error message to be displayed at the end.          *
 *                                                                          *
 * out  - all psx86 and pcx systems are shutdown.  an error message,        *
 *  including 'error' is displayed to the console.  pex then returns to the *
 *  os.                                                                     *
\****************************************************************************/
void    pexError(   char    *error  )
{
    pexErrorDisp = 1;
    pexErrorMsg = error;
    exit( 1 );
}

/****************************************************************************\
 * pexEndSplash()                                                           *
 *                                                                          *
 * desc - displays some text about pex, and who helped, etc.                *
 *                                                                          *
 * in   - we're in a text mode.                                             *
 *                                                                          *
 * out  - splash screen has been written out.                               *
\****************************************************************************/
void    pexEndSplash(   void    )
{
    printf( "pex v%s by Maxon (aka Geoffrey Wossum)\n", pex_version );
    printf( "build %s\n\n", pex_build );
    printf( "thanks and greets go out to -\n" );
    printf( "\tSahara Surfers for MIDAS\n" );
    printf( "\tTran and Daredevil for PMODE/W\n" );
    printf( "\tMario Rodriguez\n" );
    printf( "\tShawn McIntire\n" );
    printf( "\tDuddie&Rafu\n" );
    printf( "\tSergio Moreira\n" );
    printf( "\tMercury Boy\n" );
    printf( "\tTommy, Jeremy, and Mycle for original inspiration.\n" );
    printf( "\n" );
    printf( "Geoffrey uses Watcom compilers, Borland assemblers and QEdit.\n" );
    printf( "Brought to you by the letter � and the number 42.\n" );
    if ( !pexDebug )
    {
        printf( "\n\nUh, trying running it with the '/debug' switch.\n" );
        printf( "Otherwise, this is all it will do right now.\n" );
    }
    return;
}

/****************************************************************************/
/* main()                                                                   */
/****************************************************************************/
int main( int argc, char *argv[] )
{
    printf( "pex v%s by Maxon (aka Geoffrey Wossum)\n", pex_version );
    printf( "build %s\n", pex_build );

    /* initialization. */
    if ( parseCL( argc, argv ) )
        return 1;

    pexStartUp();
    if ( pexDebug )
        debugShell();

    /* deinitialization. */
    pexShutDown();

    return 0;
}

/****************************************************************************\
 * end of pex.c                                                             *
\****************************************************************************/
