/****************************************************************************\
 * intel.c                                                                  *
 * intel side stuff.                                                        *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

/* a long time ago, September 1997, I was going to write a small, fake disasm
 * for the recompiled mips code.  It didn't even come close to working.
 * anyone, it's still here.
*/

#include <stdio.h>
#include "general.h"
#include "cpu.h"
#include "mips.h"

/****************************************************************************\
 * data.                                                                    *
\****************************************************************************/
char    *intelAsm[] =
    {   "mov     eax, [ %s ]\0r",
        "mov     ebx, [ %s ]\0r",
        "add     eax, ebx",
        "mov     [ %s ], eax\0r",
        "mov     ebx, 0x%x\0i",
        "and     eax, ebx\0",
        "cmp     eax, ebx\0",
        "je      0x%x\0i",
        "cmp     eax, 0\0",
        "jge     0x%x\0i",
        "add     ebx, 8\0",
        "jg      0x%x\0i",
        "jle     0x%x\0i",
        "jl      0x%x\0i",
        "jne     0x%x\0i",
        "jmp     dword ptr [ 0x%x ]\0i",
        "nop\0i",
        "mov     ecx, [ %s ]\0r",
        "mov     eax, ebx\0",
        "div     ecx\0",
        "mov     [ %s ], ebx\0r",
        "sub     ebx, eax\0",
        "mul     ecx\0",
        "jmp     0x%x\0i",
        "mov     eax, 0x%x\0i",
        "mov     edx, [ %s ]\0r",
        "shr     edx, 2\0",
        "jmp     dword ptr [ 0x%x + edx ]\0i",
        "mov     eax, 0x%x",
        "ERROR!\0"  }; //28

char    *intelOpcodes[] =
    {   "\xa1",
        "\x8b\x1d",
        "\x03\xc3",
        "\xa3",
        "\xbb",
        "\x23\xc3",
        "\x3b\xc3",
        "\x0f\x84",
        "\x83\xf8\x00",
        "\x0f\x8d",
        "\x83\xc3\x08",
        "\x0f\x8f",
        "\x0f\x8e",
        "\x0f\x8c",
        "\x0f\x85",
        "\xff\x25",
        "\x90",
        "\x8b\x0d",
        "\x8b\xc3",
        "\xf7\xf1",
        "\x89\x1d",
        "\x2b\xd8",
        "\xf7\xe1",
        "\xe9",
        "\xb8",
        "\x8b\x15",
        "\xc1\xea\x02",
        "\xff\xa2",
        "\xb8"  };
#define intelNumOpcodes  29

/****************************************************************************/
/* intelDisasm()                                                            */
/****************************************************************************/
char    *intelDisasm(   char    *buf,
                        char    *intelptr   )
{
    int     ptr;
    char    *ctrl;
    char    *asm;
    ulong   *operand;
    ulong   reg;

    ptr = 0;
    while ( (ptr < intelNumOpcodes) &&
            (memcpy( intelOpcodes[ ptr ], intelptr, strlen( intelOpcodes[ ptr ] ) ) ) )
        ptr++;

    asm = intelAsm[ ptr ];
    ctrl = asm + strlen( asm );
    operand = (ulong*) (intelptr + strlen( asm ));

    switch ( *ctrl )
    {
        case '\0'   :   sprintf( buf, asm );
                        break;
        case 'i'    :   sprintf( buf, asm, *operand );
                        break;
        case 'r'    :   reg = ( (*operand) - (ulong) cpuGPR ) / 4;
                        sprintf( buf, asm, mipsGPRname[ reg ] );
                        break;
//        default     :   sprintf( buf, "ERROR!" );
    }

    intelptr += strlen( asm );
    if ( ctrl != '\0' )
        intelptr += 4;

    return intelptr;
}

/****************************************************************************\
 * end of intel.c                                                           *
\****************************************************************************/
