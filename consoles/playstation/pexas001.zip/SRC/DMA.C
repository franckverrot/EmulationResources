/****************************************************************************\
 * dma.c                                                                    *
 * psx dma emulation.                                                       *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include "general.h"
#include "pex.h"
#include "memory.h"
#include "dma.h"

/****************************************************************************\
 * void dmaD0_MADRhandler( void )
 *
 * desc - handles the MDEC IN Memory ADdRess register (0x1f801080).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD0_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD0_BCRhandler( void )
 *
 * desc - handles the MDEC IN Block Control Register (0x1f801084).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD0_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD0_CHCRhandler( void )
 *
 * desc - handles the MDEC IN CHannel Control Register (0x1f801088).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD0_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD1_MADRhandler( void )
 *
 * desc - handles the MDEC OUT Memory ADdRess register (0x1f801090).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD1_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD1_BCRhandler( void )
 *
 * desc - handles the MDEC OUT Block Control Register (0x1f801094).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD1_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD1_CHCRhandler( void )
 *
 * desc - handles the MDEC IN CHannel Control Register (0x1f801098).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD1_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD2_MADRhandler( void )
 *
 * desc - handles the GPU Memory ADdRess register (0x1f8010a0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD2_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD2_BCRhandler( void )
 *
 * desc - handles the GPU Block Control Register (0x1f8010a4).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD2_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD2_CHCRhandler( void )
 *
 * desc - handles the GPU CHannel Control Register (0x1f8010a8).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD2_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD3_MADRhandler( void )
 *
 * desc - handles the CDROM Memory ADdRess register (0x1f8010b0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD3_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD3_BCRhandler( void )
 *
 * desc - handles the CDROM Block Control Register (0x1f8010b4).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD3_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD3_CHCRhandler( void )
 *
 * desc - handles the CDROM CHannel Control Register (0x1f8010b8).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD3_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD4_MADRhandler( void )
 *
 * desc - handles the SPU Memory ADdRess register (0x1f8010c0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD4_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD4_BCRhandler( void )
 *
 * desc - handles the SPU Block Control Register (0x1f8010c4).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD4_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD4_CHCRhandler( void )
 *
 * desc - handles the SPU CHannel Control Register (0x1f8010c8).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD4_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD5_MADRhandler( void )
 *
 * desc - handles the ??? Memory ADdRess register (0x1f8010d0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD5_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD5_BCRhandler( void )
 *
 * desc - handles the ??? Block Control Register (0x1f8010d4).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD5_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD5_CHCRhandler( void )
 *
 * desc - handles the ??? CHannel Control Register (0x1f8010d8).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD5_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD6_MADRhandler( void )
 *
 * desc - handles the OT Memory ADdRess register (0x1f8010e0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD6_MADRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD6_BCRhandler( void )
 *
 * desc - handles the OT Block Control Register (0x1f8010e4).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD6_BCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD6_CHCRhandler( void )
 *
 * desc - handles the OT CHannel Control Register (0x1f8010e8).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD6_CHCRhandler(  void    )
{
    return;
}

/****************************************************************************\
 * void dmaD_PCRhandler( void )
 *
 * desc - handles the DMAC P Control Register (0x1f8010f0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD_PCRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * void dmaD_ICRhandler( void )
 *
 * desc - handles the DMAC I Control Register (0x1f8010f0).
 *
 * in   - this should never be called directly.
 *
 * out  -
\****************************************************************************/
void    dmaD_ICRhandler(   void    )
{
    return;
}

/****************************************************************************\
 * int dmaInit( void )
 *
 * desc - initializes pex emulated DMA services.
 *
 * in   - memoryInit() must be called before dmaInit().
 *
 * out  - dma emulation is ready for work.
\****************************************************************************/
int     dmaInit(    void    )
{
    // install hardware register handlers for DMA services.
    // dma channel 0.
    memoryRegisterTbl[ 0x1080 / 4 ] = &dmaD0_MADRhandler;
    memoryRegisterTbl[ 0x1084 / 4 ] = &dmaD0_BCRhandler;
    memoryRegisterTbl[ 0x1088 / 4 ] = &dmaD0_CHCRhandler;
    // dma channel 1.
    memoryRegisterTbl[ 0x1090 / 4 ] = &dmaD1_MADRhandler;
    memoryRegisterTbl[ 0x1094 / 4 ] = &dmaD1_BCRhandler;
    memoryRegisterTbl[ 0x1098 / 4 ] = &dmaD1_CHCRhandler;
    // dma channel 2.
    memoryRegisterTbl[ 0x10a0 / 4 ] = &dmaD2_MADRhandler;
    memoryRegisterTbl[ 0x10a4 / 4 ] = &dmaD2_BCRhandler;
    memoryRegisterTbl[ 0x10a8 / 4 ] = &dmaD2_CHCRhandler;
    // dma channel 3.
    memoryRegisterTbl[ 0x10b0 / 4 ] = &dmaD3_MADRhandler;
    memoryRegisterTbl[ 0x10b4 / 4 ] = &dmaD3_BCRhandler;
    memoryRegisterTbl[ 0x10b8 / 4 ] = &dmaD3_CHCRhandler;
    // dma channel 4.
    memoryRegisterTbl[ 0x10c0 / 4 ] = &dmaD4_MADRhandler;
    memoryRegisterTbl[ 0x10c4 / 4 ] = &dmaD4_BCRhandler;
    memoryRegisterTbl[ 0x10c8 / 4 ] = &dmaD4_CHCRhandler;
    // dma channel 5.
    memoryRegisterTbl[ 0x10d0 / 4 ] = &dmaD5_MADRhandler;
    memoryRegisterTbl[ 0x10d4 / 4 ] = &dmaD5_BCRhandler;
    memoryRegisterTbl[ 0x10d8 / 4 ] = &dmaD5_CHCRhandler;
    // dma channel 6.
    memoryRegisterTbl[ 0x10e0 / 4 ] = &dmaD6_MADRhandler;
    memoryRegisterTbl[ 0x10e4 / 4 ] = &dmaD6_BCRhandler;
    memoryRegisterTbl[ 0x10e8 / 4 ] = &dmaD6_CHCRhandler;
    // dma master.
    memoryRegisterTbl[ 0x10f0 / 4 ] = &dmaD_PCRhandler;
    memoryRegisterTbl[ 0x10f4 / 4 ] = &dmaD_ICRhandler;

    pexMesg( stderr, "dma services active.\n" );
    return 0;
}

/****************************************************************************\
 * end of dma.c                                                             *
\****************************************************************************/
