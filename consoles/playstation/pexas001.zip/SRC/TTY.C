/****************************************************************************\
 * tty.c                                                                    *
 * psx86 PEX-1000 tty device support.  a work in progress, obviously!       *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <stdio.h>
#include "general.h"
#include "pex.h"
#include "kernel.h"

/****************************************************************************\
 * global data.
\****************************************************************************/
FILE    *ttySTDOUT;         // where serial output is redirected.
char    ttyName[] = "tty";  // name of tty device in PEX-1000.
char    ttyDesc[] = "tty";  // description of tty device in PEX-1000.
char    ttyBlockSize = 1;   // data block size for tty device (1 byte).


/****************************************************************************\
 * void ttyOpen( void )
 *
 * desc - initializes PEX-1000 tty device.
 *
 * in  - nothing.
 *
 * out - tty device for PEX-1000 has been initialized.  all tty functions
 *       can be safely used.
\****************************************************************************/
void    ttyOpen(    void    )
{
    // open file to redirect serial output to.
    ttySTDOUT = fopen( "stdout", "w" );
    if ( ttySTDOUT == NULL )
        pexError( "unable to open tty device.\n" );

    return;
}

/****************************************************************************\
 * void ttyClose( void )
 *
 * desc - releases resources used by PEX-1000 tty device.
 *
 * in   - shutdowns PEX-1000 tty device.
 *
 * out  - serial redirection file has been closed.  the PEX-1000 tty device
 *  should not be used after ttyClose has been called.
\****************************************************************************/
void    ttyClose(   void    )
{
    fclose( ttySTDOUT );

    return;
}

/****************************************************************************\
 * void ttyIoctl( void )
 *
 * desc - IOCTL function referred to in psx IO device driver.
 *
 * in   - ???
 *
 * out  - ???
\****************************************************************************/
void    ttyIoctl(   void    )
{
    return;
}

/****************************************************************************\
 * void ttyRead( void )
 *
 * desc - READ function referred to in psx IO device driver.
 *
 * in   - ???
 *
 * out  - ???
\****************************************************************************/
void    ttyRead(    void    )
{

}

/****************************************************************************\
 * end of tty.c                                                             *
\****************************************************************************/
