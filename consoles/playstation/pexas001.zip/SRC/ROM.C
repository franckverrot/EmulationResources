/****************************************************************************/
/* rom.c                                                                    */
/* SCPH rom support for pex.                                                */
/****************************************************************************/
/* This source code is part of the pex Sony Playstation emulator project.   */
/* Copyright 1997 Geoffrey Wossum, all rights reserved.                     */
/* This version of the pex source code is NOT FOR DISTRIBUTION.             */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <direct.h>
#include "general.h"
#include "pex.h"
#include "memory.h"
#include "rom.h"

/****************************************************************************/
/* global data.                                                             */
/****************************************************************************/
char    *romImageList[] =
    {   "PSX.ROM",      "SCPH1000.BIN", "SCPH5000.BIN", "SCPH5500.BIN",
        "DTLH3000.BIN", ""  };

/****************************************************************************/
/* romLoadImage()                                                           */
/****************************************************************************/
int     romLoadImage(   void    )
{
    FILE    *image;
    int     j, check;

    image = NULL;
    j = 0;
    while ( ( strcmp( romImageList[ j ], "" ) ) && ( image == NULL ) )
    {
        image = fopen( romImageList[ j ], "rb" );
        if ( image == NULL )
            j++;
    }

    if ( !strcmp( romImageList[ j ], "" ) )
        pexError( "unable to locate a psx rom image!" );
    pexMesg( stderr, "using rom image file %s\n", romImageList[ j ] );

    check = fread( memoryROM, 1, memoryROMsize, image );
    if ( check != memoryROMsize )
        pexError( "error reading psx rom image!" );

    fclose( image );
    pexMesg( stderr, "psx rom image successfully loaded.\n" );

    return 0;
}

/****************************************************************************/
/* romIdImage()                                                             */
/****************************************************************************/
int     romIdImage( romSupportHeader    *header,
                    FILE                *support )
{
    int         j;
    int         flag;
    char        idbuf[ 128 ];
    romIdHeader idheader;

    flag = 0;
    fseek( support, header->idPtr, SEEK_SET );

    for ( j = 0; j < header->idStrings; j++ )
    {
        fread( &idheader, 1, sizeof( idheader ), support );
        fread( idbuf, 1, idheader.idLen, support );
        flag |= memcmp( (void*) idbuf, (void*) memoryConvert( idheader.idPtr ),
            idheader.idLen );
    }

    return !flag;
}

/****************************************************************************/
/* romModImage()                                                            */
/****************************************************************************/
int     romModImage(    romSupportHeader    *header,
                        FILE                *support    )
{
    int             j;
    char            modbuf[ 1024 ];
    romModHeader    modheader;

    fseek( support, header->modPtr, SEEK_SET );

    for ( j = 0; j < header->modStrings; j++ )
    {
        fread( &modheader, 1, sizeof( modheader ), support );
        fread( modbuf, 1, modheader.modLen, support );
        memcpy( (void*) memoryConvert( modheader.modPtr ), (void*) modbuf,
            modheader.modLen );
    }

    return 0;
}

/****************************************************************************/
/* romPatch()                                                               */
/****************************************************************************/
int     romPatch(   void    )
{
    DIR                 *dir;
    struct dirent       *entry;
    FILE                *support;
    romSupportHeader    header;
    int                 idPos;


    dir = opendir( "*.prs" );
    entry = readdir( dir );
    idPos = 0;
    while ( ( entry != NULL ) && ( !idPos ) )
    {
        support = fopen( entry->d_name, "rb" );
        fread( &header, sizeof( romSupportHeader ), 1, support );
        idPos = romIdImage( &header, support );
        if ( !idPos )
        {
            fclose( support );
            entry = readdir( dir );
        }
    }
    closedir( dir );

    if ( idPos )
    {
        pexMesg( stderr, "rom image identified as %s\n", header.romName );
    }
    else
    {
        pexError( "no rom support for current rom image.\n" );
    } 

    romModImage( &header, support );

    fclose( support );
    pexMesg( stderr, "rom image patched.\n" );
    return 0;
}

/****************************************************************************/
/* end of rom.c                                                             */
/****************************************************************************/
