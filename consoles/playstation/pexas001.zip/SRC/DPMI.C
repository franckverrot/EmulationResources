/****************************************************************************\
 * dpmi.c                                                                   *
 * dpmi functions required by pex.                                          *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/

#include <i86.h>



/****************************************************************************\
 * end of dpmi.c                                                            *
\****************************************************************************/
