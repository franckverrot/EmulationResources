/****************************************************************************\
 * dynamap.c                                                                *
 * routines so pex knows when to dyna-compile.                              *
\****************************************************************************/

#include <stdio.h>
#include "general.h"
#include "pex.h"
#include "cpu.h"
#include "memory.h"
#include "dynamap.h"
#include "debug.h"

/****************************************************************************\
 * global data.                                                             *
\****************************************************************************/
ulong   dynamapWork = 0; // set to 1 right after a dyna-compile.

/****************************************************************************\
 * int dynamapInit( void )
 *
 * desc - initializes the psx86 dynamap system.
 *
 * in   - memoryInit should have been called before dynamapInit.
 *
 * out  - dynamap sector processors have been created.
 *  the memoryXlatTbl has been modified to point to the sector processors.
 *  the dynamap processor has been setup.
 *  all ram in the ram has been set with an illegal "virgin" value.
 *  always returns 0.
\****************************************************************************/
int     dynamapInit(    void    )
{
    ulong   j, k;       // lcv's.
    ulong   xlatptr;    // points to the xlat of the psx addr we're working on.

    xlatptr = 0;

    for ( j = 0; j < 2048 * 1024 / 4; j++ )
    {
        // for each dword alligned address, point the xlat to dynmapProcess.
        *memoryXlat( xlatptr ) = (ulong) &dynamapProcess;
        xlatptr += 4;
    }

    // set all "ram" to an illegal "virgin" value.
    memset( memoryRAM, dynamapVirgin, memoryRAMsize );

    pexMesg( stderr, "dynamap initialized.\n" );

    return 0;
}

/****************************************************************************\
 * int dynamapDeinit( void )
 *
 * desc - shuts down dynamap.
 *
 * in   - this function should not be called before dynamapInit().
 *
 * out  - all resource used by dynamap have been released.  dynamap is no
 *  longer active.  using the r3000 after a call to this function could have
 *  unpredictable results.
\****************************************************************************/
int     dynamapDeinit(  void    )
{
    pexMesg( stderr, "dynamap closed.\n" );
    return 0;
}

/****************************************************************************\
 * void dynamapProcess( void )
 *
 * desc - this function is eventually called whenever the cpu tries to
 *  execute an opcode that has not been recompiled yet.  using dynamapSector
 *  it determines the location and size of memory it should recompile, and
 *  then calls the mips-x86 compiler on that region of memory.
 *
 * in   - this procedure should never be called directly.  it should only be
 *  called by the dynamap sector processors.
 *
 * out  - a region of psx memory, including the opcode that caused the dynamap
 *  signal, has been recompiled into x86 code.
\****************************************************************************/
void    dynamapProcess( void    )
{
    ulong   *loptr;     // pc space pointer to first opcode to recompile.
    ulong   *hiptr;     // pc space pointer to last opcode to recomile.
    ulong   *noptr;     // I forgot.
    ulong   psxlo;      // psx space pointer to first opcode to recompile.
    ulong   psxhi;      // psx space pointer to last opcode to recompile.
    ulong   size;       // size (in bytes) of area to be recompiled.
    ulong   nopcnt;     // count number of consecutive NOP's.

    pexMesg( stderr, "dynamap signal received at %08x (PC).\n", cpuPC );

    // get first possible loptr in psx space..
    psxlo = cpuPC;
    // convert psx space pointer to pc space pointer.
    noptr = (ulong*) memoryConvert( psxlo );
    loptr = noptr;

    // find the highest non-virgin bit of memory in THIS sector.
    while ( (*loptr) == dynamapVirginOp )
        loptr++;

    // we'll start search for last non-virgin from current loptr.
    hiptr = loptr;

    // find the lowest non-virgin bit of memory.  this can go to other sectors.
    nopcnt = 0;
    while ( ( (*loptr) != dynamapVirginOp ) &&
            ( loptr > (ulong*) memoryRAM ) )
    {
        if ( (*loptr) == 0 )    // detect a NOP.
        {
            nopcnt++;
            // if we've hit more consecutive NOP's than we can tolerate...
            // break out of the lo seeking loop.
            if ( nopcnt >= dynamapNopTolerance )
                break;
        }
        else
            nopcnt = 0;
        loptr--;
    }

    // convert pc space 'loptr' to psx space 'psxlo'.
    psxlo -= (noptr - loptr) * 4;

    // find highest non-virgin bit of memory.  this can go to other sectors.
    while ( (*hiptr) != dynamapVirginOp )
        hiptr++;

    // find size (in bytes) of non-virgin memory area.
    size = (ulong) (hiptr - loptr) * 4 + 4;
    psxhi = psxlo + size;

/*
    pexMesg( stderr, "original plan : %x - %x\n", psxlo, psxhi );
    memoryBoundIntel( &psxlo, &psxhi );
    size = psxhi - psxlo;
    pexMesg( stderr, "new plan : %x - %x\n", psxlo, psxhi );
*/
    // compile area that we've marked as having been modified.
    debugUnlinkBP();
    compilerCompile( psxlo, size );
    debugRelinkBP();

    // we've worked, so set the work flag to true.
    dynamapWork = 1;

    // with the current debugger implementation, this will return to the
    // r3kshell, which will then re-execute the opcode that retriggered this
    // dynamap signal.
    return;
}

/****************************************************************************\
 * end of dynamap.c                                                         *
\****************************************************************************/
