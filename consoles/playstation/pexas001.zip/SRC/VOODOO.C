/****************************************************************************\
 * voodoo.c                                                                 *
 * basic Glide functions for Glide pex.                                     *
\****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "general.h"
#include "pex.h"
#include "voodoo.h"
#include "glide.h"

/****************************************************************************\
 * int voodooInit( void )
 *
 * desc - initializes Glide pex's 3Dfx interface.
 *
 * in   - nothing.
 *
 * out  - always returns 0.
 *  Voodoo has been initialzed and opened.  voodoo interface functions can
 *  be called now.
\****************************************************************************/
int     voodooInit( void    )
{
    GrHwConfiguration   hw; // holds 3Dfx board configuration.
    
    // this Voodoo init is almost straight from the Glide documentation.
    grGlideInit();
    if ( !grSstQueryHardware( &hw ) )
        pexError( "Glide pex requires a 3Dfx Voodoo or Voodoo Rush.\n" );

    grSstSelect( 0 );
    grSstWinOpen( NULL, GR_RESOLUTION_640x480, GR_REFRESH_60Hz,
        GR_COLORFORMAT_RGBA, GR_ORIGIN_UPPER_LEFT, 2, 0 );

    return 0;
}

/****************************************************************************\
 * int voodooDeinit( void )
 *
 * desc - shutdowns Glide pex's voodoo interface.
 *
 * in   - voodooInit should have been previously called.
 *
 * out  - 3Dfx Voodoo board has been shutdown.  calls to the voodoo
 *  interface should not be called after the voodooDeinit called.
\****************************************************************************/
int     voodooDeinit(   void    )
{
    grGlideShutdown();
    return 0;
}

/****************************************************************************\
 * end of voodoo.c                                                          *
\****************************************************************************/
