/****************************************************************************\
 * gte.c                                                                    *
 * emulation of hardware and interface of psx GTE.                          *
 ****************************************************************************
 * This source code is part of the pex Sony Playstation emulator project.   *
 * Copyright 1997 Geoffrey Wossum, all rights reserved.                     *
 * This version of the pex source code is NOT FOR DISTRIBUTION.             *
\****************************************************************************/




/****************************************************************************\
 * end of gte.c                                                             *
\****************************************************************************/
