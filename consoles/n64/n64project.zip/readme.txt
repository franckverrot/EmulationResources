N64 Controller Port Pinout
By CrowKiller

Tired of those playstation people with their cheap homemade 
memory card interface, gonna roll my own in a very near future....

Real non-ASCII schematics will be made avaiable shortly to Dextrose.

CrowKiler

--==> hardware hacking will go on forever <==--

