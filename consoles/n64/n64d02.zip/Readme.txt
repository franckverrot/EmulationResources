-------------------------------------------------------
N64d (v0.2)
-------------------------------------------------------
A compilation of N64 programming and hardware documents
1997 by Denary Notation
-------------------------------------------------------

Note: if you're reading this doc in Notepad, use the word-wrap function

|About N64d|

N64d is a compilation of Nintendo64-related documents. Although mainly
concentrating on the technical side of the console, other useful info will
be provided (such as how to run Jap games on your USA system).
Most of the info found here is not exclusive to ourselves. It is available
freely on many publications, either web-based or paper-based. However, most, 
if not all documents have been completely RE-WRITTEN, overhauled and added to by ourselves in order improve relevancy and aesthetics. Each doc comes
with a source location, so you can easily look up missing or incomplete facts.

This is version 0.2 of N64d and is the second public release.

|What's new in this version?|

Unfortunately - not much. All previously incomplete documents are now, well, complete. There is one extra doc included giving tech-specs on the N64dd add-on. NO - we still haven't documented the Rambus DRAM system - Sorry! 
This version is less of a real update, more of a stop-gap until we find the time for full development.
Feel free to upload this version of the doc onto your web-site or BBS as all previous inaccuracies have been dealt with. 

|What files are included in version 0.2 of N64d?|

Readme.txt  - This file.
N64tech.doc - The technical specs of the N64.
DDtech.doc  - Tech specs on the N64dd
R4300.doc  - Technical info on the N64 processor (now 100% complete).
CP0.doc     - Background information on the R4300i co-processor.
CP0reg.doc  - Register definitions for the above.
USA-Jap.doc - Jap<=>USA cart conversion guide.
N64rgb.zip  - RGB lead conversion guide (not compiled by us, taken straight from the web).
Also:-
Ascii.zip   - No longer included.

|Who are the authors?|

N64d was put together by:-

Jim Lambert (leatherdude@mcmail.com) - AKA "LeatherWing"
Paul Hauffman (bandaid@mcmail.com)   - AKA "Bandages"
Andy Simpson (currently without net provider)

|Homepage URL|

http://www.denary-notation.mcmail.com/
For the World of Emulation

|Disclaimer|

The authors take no responsibility for use or misuse of the docs included
in this compilation. Users are free to use it as they please. Information can be re-distributed without notifying the authors - this includes web-page publishing and spin-off documents. However, it would be nice if we are told when our docs are being used by others - it gives us incentive!

If any aspect of our docs are deemed unsuitable for publication or distribution by connected persons, then contact us and we will work it out with you!

Have fun!!!! ;)  
 
LeatherWing 