Included in this zip are data tables taken from Street Fighter Zero (Japan).

Files sfz-xxxx.rom are dumps of data through the encryption system where the
initial 03 socketed ROM is filled with the word value shown in the filename.
The encryption system uses only 17 bits of the possible 24 address lines so
tables repeat on 0x20000 boundries.

The file sfz_0x000000.txt is a table giving all posibilities for address 0x000000.
Values on the left side are whats placed in the ROM at this address, values on the
right are the results after being processed via the encryption system. Both the
encrypted and decrypted values in this table will need to be byteswapped if you
wish this data to match the byte layout in the sfz-xxxx.rom files.

Razoola



