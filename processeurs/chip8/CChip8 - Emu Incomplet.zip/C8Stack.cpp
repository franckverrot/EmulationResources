// C8Stack.cpp: implementation of the C8Stack class.
//
//////////////////////////////////////////////////////////////////////

#include "C8Stack.h"
#include <string.h>
#include <stdlib.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C8Stack::C8Stack()
{
	this->retcall = (int*)malloc(sizeof(int)*0xF);
	memset(this->retcall,-1,sizeof(this->retcall));
}

C8Stack::~C8Stack()
{
	delete this->retcall;
}

int C8Stack::push(int data)
{
	unsigned int i = 0;

	while(i <= 0xF)
	{
		if(this->retcall[i] == -1)
			break;
		else
			i++;
	}

	this->retcall[i] = data;

	return this->retcall[i];
}

int C8Stack::pop()
{
	unsigned int i = 0;

	while(i <= 0xF)
	{
		if(this->retcall[i] == -1)
			break;
		else
			i++;
	}

	return this->retcall[i-1];
}