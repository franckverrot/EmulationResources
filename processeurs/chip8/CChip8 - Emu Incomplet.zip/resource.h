//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ressources.rc
//
#define IDR_MENU                       103
#define ID_ROMS_OPEN                    40001
#define ID_ROMS_INFORMATIONS            40002
#define ID_ROMS_EXIT                    40003
#define ID_SYSTEM_RUN                   40004
#define ID_SYSTEM_PAUSE                 40005
#define ID_SYSTEM_RESET                 40006
#define ID_HELP_ABOUT                   40007
#define ID_QUIT                         40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
