#include "CChip8.h"

CChip8::CChip8()
{
    /* mise de l'index I � 0 */
    this->I = 0;

    /* mise de la m�moire du syst�me � 0 */
    memset(this->mem,0,sizeof(this->mem));

    /* d�but du programme � l'offset m�moire 0x200(h) */
    this->PC = 0x200;

    /* mise � 0 des registres */
    memset(this->reg,0,sizeof(this->reg));

    /* efface l'�cran */
    this->cls();

    /* pointeur de pile � 0 */
   // memset(this->SP, 0, sizeof(this->SP));

    /* make non autoboot game */
    this->run = 0;

	/* rom_name = 0s */
	memset(this->rom_name,0,sizeof(rom_name));

}

CChip8::~CChip8()
{
return;
}

void CChip8::Hard_reset()
{
    /* mise de l'index I � 0 */
    this->I = 0;
    
    /* mise de la m�moire du syst�me � 0 */
    memset(this->mem,0,sizeof(this->mem));
    
    /* d�but du programme � l'offset m�moire 0x200(h) */
    this->PC = 0x200;
    
    /* mise � 0 des registres */
    memset(this->reg,0,sizeof(this->reg));
    
    /* efface l'�cran */
    this->cls();
    
    /* pointeur de pile � 0 */
//    memset(this->SP, 0, sizeof(this->SP));
}

int CChip8::LoadROM(char *filename)
{
    /* file's handle */
    FILE *fp;
    int size=0,f_lenght=0;

    /* open file */
    if(NULL == (fp = fopen(filename,"rb")))
        return -1;
        
    /* filling memory */
    /* keep in mind that program starts at 0x200 */

	/* get file size */
	fseek(fp,0,SEEK_END);
	f_lenght = ftell(fp);
	fseek(fp,0,SEEK_SET);
	
    /* read all the data */
    if(f_lenght != (size = fread(this->mem + 0x200, f_lenght,sizeof(char),fp)))
	{
		return -2;
	}
            
    else 
	{
		/* ...and then fill buffer with 0s */
		for(int i = f_lenght; i < sizeof(this->mem);i++)
			this->mem[i] = 0;

		/* copy filename to rom_name */
		if(strlen(filename) > 255)
			filename[255] = 0;
		strncpy(filename,this->rom_name,255);

        return 0;
	}
}

void CChip8::Run()
{
    this->run = 1;
}

void CChip8::Pause()
{
    this->run = 0;
}

void CChip8::Emulate()
{
        /* temporary opcode and its init */
        unsigned char op[2];
        memset(op,0,sizeof(op));
        
        /* fetch entire opcode */
        this->opcode = this->mem[PC] * 0x100 + this->mem[PC+1];
        
        /* fetch opcode and operands */
        op[0] = this->mem[PC];
        op[1] = this->mem[PC+1];
        
        /* execute opcode */
        switch(op[0] & 0xF0)
        {
        case 0:
                {
                switch(op[1] & 0xF0)
                        {
                          case 0xC:
                              {
                // 00Cx instruction
                // SChip only
                              }
                              break;
                              
                          case 0xE:
                              {
                              switch(op[1] & 0x0F)
                              {
                              case 0x0:
                                    {
                                    this->cls();
                                    }
                                    break;
                              case 0xE:
                                    {
                                    this->rts();
                                    }
                                    break;
                                    
                              }
                              }
                              break;
                                                       
                          case 0xF:
                              {
                              switch(op[1] & 0x0F)
                              {
                              case 0xB:
                                    {
                                    this->scright();
                                    }
                                    break;
                              case 0xC:
                                    {
                                    this->scleft();
                                    }
                                    break;
                              case 0xE:
                                    {
                                    this->low();
                                    }
                                    break;
                              case 0xF:
                                    {
                                    this->high();
                                    }
                                    break;
                              }
                              }
                              break;
                              
                         }
                break;
                
         case 1:
                {
                this->jmp((op[0]&0x0F)*0x100+op[1]);
                }
                break;
                
         case 2:
                {
                this->jsr((op[0]&0x0F)*0x100+op[1]);
                }
                break;
         
         case 3:
                  {
                  this->skeq_const(op[0]&0x0F,op[1]);
                  }
                  break;
 
         case 4:
                  {
                  this->skne_const(op[0]&0x0F,op[1]);
                  }
                  break;
         case 5:
                  {
                  this->skeq_reg(op[0]&0x0F,op[1]);
                  }
                  break;
         case 6:
                  {
                  this->mov_const(op[0]&0x0F,op[1]);
                  }
                  break;
         case 7:
                  {
                  this->add_const(op[0]&0x0F,op[1]);
                  }
                  break;
         case 8:
                  {
                  switch(op[1]&0x0F)
                    {
                          case 0:
                          {
                          this->mov_reg(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 1:
                          {
                          this->or(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 2:
                          {
                          this->and(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 3:
                          {
                          this->xor(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 4:
                          {
                          this->add_reg(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 5:
                          {
                          this->sub(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 6:
                          {
                          if(op[1]&0xF0 == 0)
                            this->shr(op[0]&0x0F);
                          }
                          break;
                          case 7:
                          {
                          this->rsb(op[0]&0x0F,op[1]&0xF0);
                          }
                          break;
                          case 0xE:
                          {
                          if(op[1]&0xF0 == 0)
                            this->shl(op[0]&0x0F);
                          
                          }
                          break;
                   }      
                  }
                  break;
                  
          case 9: 
          {
          if(op[1]&0x0F == 0)
                    this->skne_reg(op[0]&0x0F,op[1]&0xF0);
          }
          break;
                  
          case 0xA: 
          {
          this->mvi((op[0]&0x0F)*0x100 + op[1]);
          }
          break; 
          
          case 0xB: 
          {
          this->jmi((op[0]&0x0F)*0x100 + op[1]);
          }
          break;                                                               

          case 0xC: 
          {
          this->rand(op[0]&0x0F, op[1]);
          }
          break; 

          case 0xD: 
          {
          if(op[1]&0x0F != 0)
            this->sprite(op[0]&0x0F, op[1]&0xF0, op[1]&0x0F);
          else
            this->xsprite(op[0]&0x0F, op[1]&0xF0);  
          }
          break; 
          
          case 0xE: 
          {
          if(op[1] == 0x9E)
            this->skpr(op[0]&0x0F);
          if(op[1] == 0xA1)
            this->skup(op[0]&0x0F); 
          }
          break;
                
          case 0xF: 
          {
          switch(op[1])
          {
          case 0x07:
               {
               this->gdelay(op[0]&0x0F);
               }
               break;
          case 0x0A:
               {
               this->key(op[0]&0x0F);
               }
               break;
          case 0x15:
               {
               this->sdelay(op[0]&0x0F);
               }
               break;
          case 0x18:
               {
               this->ssound(op[0]&0x0F);
               }
               break;
          case 0x1E:
               {
               this->adi(op[0]&0x0F);
               }
               break;
          case 0x29:
               {
               this->font(op[0]&0x0F);
               }
               break;
          case 0x30:
               {
               this->xfont(op[0]&0x0F);
               }
               break;
          case 0x33:
               {
               this->bcd(op[0]&0x0F);
               }
               break;
          case 0x55:
               {
               this->str(op[0]&0x0F);               
               }
               break;
          case 0x65:
               {
               this->ldr(op[0]&0x0F);
               }
               break;
          }
          }
          break;
          
                                                                                                                                                                                                                                                                                                                                                      
          default: break;                          
        }
                        
    }                                                                            
        /* keep running! */
        this->PC += 2;
}


void CChip8::cls()
{
    memset(this->screen,0,sizeof(this->screen));
}

void CChip8::rts()
{
		this->PC = this->SP.pop();
}

void CChip8::scright()
{
}

void CChip8::scleft()
{
}

void CChip8::low()
{
}

void CChip8::high()
{
}

void CChip8::jmp(int offset)
{
	this->PC = offset;
}

void CChip8::jsr(int offset)
{
	this->SP.push(this->PC+2);
	this->PC = offset;
}

void CChip8::skeq_const(int reg, int constant)
{
	this->reg[reg] = constant ? this->PC+=4 : this->PC+=2;
}

void CChip8::skne_const(int reg, int constant) 
{
	this->reg[reg] != constant ? this->PC+=4 : this->PC+=2;
}

void CChip8::skeq_reg(int reg, int reg2)         
{
	this->reg[reg] = this->reg[reg2] ? this->PC+=4 : this->PC+=2;
}

void CChip8::mov_const(int reg, int constant)
{
	this->reg[reg] = constant;
}

void CChip8::add_const(int reg, int constant)
{
	this->reg[reg] += constant;
}

void CChip8::mov_reg(int reg_src, int reg_dest)
{
}

void CChip8::or(int reg_src, int reg_dest)
{
}

void CChip8::and(int reg_src, int reg_dest)    
{
}

void CChip8::xor(int reg_src, int reg_dest)
{
	this->reg[reg_dest] ^= this->reg[reg_src];
}

void CChip8::add_reg(int reg_src, int reg_dest)    
{
	this->reg[reg_dest] += this->reg[reg_src];
}

void CChip8::sub(int reg_src, int reg_dest)
{
	this->reg[reg_dest] -= this->reg[reg_src];
	if(this->reg[reg_dest] < 0)
		this->reg[0xF] = 1;
}

void CChip8::shr(int reg)
{
	int temp = 0;

	temp = this->reg[reg];
	temp -= ((this->reg[reg] >> 1) << 1);
	if(this->reg[reg] - temp == 1)
		this->reg[0xF] = 1;
	else this->reg[0xF] = 0;
	this->reg[reg] >>= 1;
}

void CChip8::rsb(int reg_src, int reg_dest)
{
	this->reg[reg_dest] -= this->reg[reg_src];
	if(this->reg[reg_dest] < 0)
		this->reg[0xF] = 1;
}

void CChip8::shl(int reg)
{
	int temp = 0;

	temp = this->reg[reg];
	temp -= ((this->reg[reg] << 1) >> 1);
		if(this->reg[reg] - temp == 128)
		this->reg[0xF] = 1;
	else this->reg[0xF] = 0;
	this->reg[reg] <<= 1;
}

void CChip8::skne_reg(int reg, int reg2)
{
	this->reg[reg] != this->reg[reg2] ? this->PC+=4 : this->PC+=2;
}

void CChip8::mvi(int offset)
{
	this->I = offset;
}

void CChip8::jmi(int offset)
{
	this->PC = this->I + this->reg[0];
}

void CChip8::rand(int reg, int max)
{
}

void CChip8::sprite(int x, int y, int height)
{
}

void CChip8::xsprite(int x,int y)
{
}

void CChip8::skpr(int key)
{
}

void CChip8::skup(int key)
{
}

void CChip8::gdelay(int reg)
{
}

void CChip8::key(int reg)
{
}

void CChip8::sdelay(int reg)
{
}

void CChip8::ssound(int reg)
{
}

void CChip8::adi(int reg)
{
}

void CChip8::font(int reg)
{
}

void CChip8::xfont(int reg)
{
}

void CChip8::bcd(int reg)
{
}

void CChip8::str(int reg)
{
}

void CChip8::ldr(int reg)
{
}

