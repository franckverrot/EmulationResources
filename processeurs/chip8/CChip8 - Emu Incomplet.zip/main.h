#define ID_MENU 501


#define IDM_OPEN        200
#define IDM_EXIT        201
#define IDM_INFOS       202
#define IDM_RUN         203
#define IDM_PAUSE       204		
#define IDM_RESET       205		
#define IDM_ABOUT       206
