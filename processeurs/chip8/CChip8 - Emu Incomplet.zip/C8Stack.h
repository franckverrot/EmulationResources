// C8Stack.h: interface for the C8Stack class.
//
//////////////////////////////////////////////////////////////////////

class C8Stack  
{
private:
	int *retcall;

public:
	C8Stack();
	virtual ~C8Stack();

	int push(int data);
	int pop();

};


