#include <iostream>
#include <string.h>
#include "C8Stack.h"

class CChip8
{
//private:
public:

	/* configuration */
	char rom_name[255];
    /* hardware emulation */
    char mem[0xFFF];
    char screen[64*32];
    char super_screen[128*64];
    char reg[0xF];
    int I;
    
    /* software emulation */
    C8Stack SP;
    int PC;
    
    int opcode;

    
//public:

    /* Is the program running? Yes if it's 0, and No if it's 1 */
    int run;
    
    /* Constructor and desctructor */
    CChip8();
    ~CChip8();
    
    /* Internal funcs */
    void Hard_reset();
    void Run();
    void Pause();

    /* rom loading sub */
    int LoadROM(char *filename);
    
    /* emulation's main func */
    void Emulate();
    
   /* Chip8 internal functions */         
    void cls();
    void rts();
    void scright();
    void scleft();
    void low();
    void high();
    void jmp(int offset);
    void jsr(int offset);
    void skeq_const(int reg, int constant);
    void skne_const(int reg, int constant); 
    void skeq_reg(int reg, int reg2);         
    void mov_const(int reg, int constant);
    void add_const(int reg, int constant);
    void mov_reg(int reg_src, int reg_dest);
    void or(int reg_src, int reg_dest);
    void and(int reg_src, int reg_dest);    
    void xor(int reg_src, int reg_dest);
    void add_reg(int reg_src, int reg_dest);    
    void sub(int reg_src, int reg_dest);
    void shr(int reg);
    void rsb(int reg_src, int reg_dest);
    void shl(int reg);
    void skne_reg(int reg, int reg2);
    void mvi(int offset);
    void jmi(int offset);
    void rand(int reg, int max);
    void sprite(int x, int y, int height);
    void xsprite(int x,int y);
    void skpr(int key);
    void skup(int key);
    void gdelay(int reg);
    void key(int reg);
    void sdelay(int reg);
    void ssound(int reg);
    void adi(int reg);
    void font(int reg);
    void xfont(int reg);
    void bcd(int reg);
    void str(int reg);
    void ldr(int reg);
    
};
